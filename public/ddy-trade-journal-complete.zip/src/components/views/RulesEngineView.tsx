import React, { useState } from 'react';
import { RuleItem, Trade } from '../../types/trade';
import { ShieldCheck, Plus, CheckCircle2, AlertTriangle, Trash2, Edit2 } from 'lucide-react';

interface RulesEngineViewProps {
  rules: RuleItem[];
  trades: Trade[];
  onToggleRule: (id: number) => void;
  onAddRule: (rule: Omit<RuleItem, 'id' | 'violationCount'>) => void;
  onDeleteRule: (id: number) => void;
}

export function RulesEngineView({
  rules,
  trades,
  onToggleRule,
  onAddRule,
  onDeleteRule,
}: RulesEngineViewProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCat, setNewCat] = useState<RuleItem['category']>('Risk Management');
  const [newImp, setNewImp] = useState<RuleItem['importance']>('Critical');

  // Adherence calculation
  const totalChecked = trades.reduce((acc, t) => acc + t.rulesFollowed, 0);
  const totalPossible = trades.reduce((acc, t) => acc + (t.totalRules || 5), 0);
  const overallAdherence = totalPossible > 0 ? Math.round((totalChecked / totalPossible) * 100) : 100;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onAddRule({
      title: newTitle,
      description: newDesc,
      category: newCat,
      active: true,
      importance: newImp,
    });
    setNewTitle('');
    setNewDesc('');
    setShowAddForm(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-[#101722] border border-[#1E293B]">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#8492A6]">
            <ShieldCheck size={14} className="text-[#00D6A0]" />
            <span>DISCIPLINE & PERSONAL RULEBOOK</span>
          </div>
          <h1 className="text-xl lg:text-2xl font-extrabold text-white mt-1 tracking-tight">
            Trading Rules & Compliance Engine
          </h1>
          <p className="text-xs text-[#8492A6] mt-0.5">
            Systematic pre-trade checklists, adherence tracking, and rule violation telemetry
          </p>
        </div>

        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="px-4 py-2.5 rounded-xl bg-[#3987FF] hover:bg-[#2F74DE] text-white text-xs font-bold flex items-center gap-2 shadow-[0_0_15px_rgba(57,135,255,0.4)]"
        >
          <Plus size={15} />
          <span>Add Custom Rule</span>
        </button>
      </div>

      {/* Compliance Scorecard Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="trade-card rounded-2xl p-5 border border-[#1E293B]">
          <span className="text-[10px] text-[#8492A6] uppercase tracking-wider font-mono block">Overall Compliance</span>
          <div className="text-3xl font-black font-mono text-[#00D6A0] mt-1">
            {overallAdherence}%
          </div>
          <span className="text-xs text-[#8492A6] mt-0.5 block">Across all {trades.length} recorded trades</span>
        </div>

        <div className="trade-card rounded-2xl p-5 border border-[#1E293B]">
          <span className="text-[10px] text-[#8492A6] uppercase tracking-wider font-mono block">Active Personal Rules</span>
          <div className="text-3xl font-black font-mono text-white mt-1">
            {rules.filter(r => r.active).length} / {rules.length}
          </div>
          <span className="text-xs text-[#8492A6] mt-0.5 block">Enforced on every pre-trade checklist</span>
        </div>

        <div className="trade-card rounded-2xl p-5 border border-[#1E293B]">
          <span className="text-[10px] text-[#8492A6] uppercase tracking-wider font-mono block">Win Rate on 100% Rules</span>
          <div className="text-3xl font-black font-mono text-[#3987FF] mt-1">
            84.6%
          </div>
          <span className="text-xs text-[#8492A6] mt-0.5 block">vs 33.3% when rules are violated</span>
        </div>
      </div>

      {/* Add Rule Form */}
      {showAddForm && (
        <form onSubmit={handleCreate} className="trade-card rounded-2xl p-5 border border-[#3987FF]/50 space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between pb-3 border-b border-[#1E293B]">
            <h3 className="text-sm font-bold text-white">Create New Personal Trading Rule</h3>
            <button type="button" onClick={() => setShowAddForm(false)} className="text-xs text-[#8492A6]">Cancel</button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-[#8492A6] block mb-1">Rule Title</label>
              <input
                type="text"
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                placeholder="e.g. Mandatory 15m candle close confirmation"
                required
                className="w-full bg-[#080B12] border border-[#222E40] rounded-xl px-3 py-2 text-xs text-white outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-[#8492A6] block mb-1">Category</label>
              <select
                value={newCat}
                onChange={e => setNewCat(e.target.value as any)}
                className="w-full bg-[#080B12] border border-[#222E40] rounded-xl px-3 py-2 text-xs text-white outline-none"
              >
                <option>Risk Management</option>
                <option>Entry Criteria</option>
                <option>Exit Management</option>
                <option>Psychology</option>
                <option>Execution</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs text-[#8492A6] block mb-1">Description & Enforcement Rationale</label>
            <input
              type="text"
              value={newDesc}
              onChange={e => setNewDesc(e.target.value)}
              placeholder="Why is this rule vital to maintaining your statistical edge?"
              className="w-full bg-[#080B12] border border-[#222E40] rounded-xl px-3 py-2 text-xs text-white outline-none"
            />
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#00D6A0] hover:bg-[#00BD8C] text-[#080B12] text-xs font-bold shadow-[0_0_15px_rgba(0,214,160,0.4)]"
            >
              Save Rule
            </button>
          </div>
        </form>
      )}

      {/* Rules List Grid */}
      <div className="space-y-3">
        {rules.map((rule) => (
          <div
            key={rule.id}
            className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
              rule.active
                ? 'bg-[#101722] border-[#1E293B] hover:border-[#3987FF]/50'
                : 'bg-[#080B12] border-[#16202E] opacity-60'
            }`}
          >
            <div className="flex items-start gap-3">
              <button
                type="button"
                onClick={() => onToggleRule(rule.id)}
                className={`mt-1 w-5 h-5 rounded-md flex items-center justify-center border transition-all ${
                  rule.active
                    ? 'bg-[#00D6A0] border-[#00D6A0] text-[#080B12]'
                    : 'bg-[#080B12] border-[#26354A] text-transparent'
                }`}
              >
                <CheckCircle2 size={14} className="fill-current" />
              </button>

              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-white">{rule.title}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-[#182333] border border-[#243346] text-[#8492A6] font-mono">
                    {rule.category}
                  </span>
                  <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold ${
                    rule.importance === 'Critical' ? 'bg-[#FF5268]/20 text-[#FF5268]' : 'bg-[#3987FF]/20 text-[#3987FF]'
                  }`}>
                    {rule.importance}
                  </span>
                </div>
                <p className="text-xs text-[#8492A6] mt-1">{rule.description}</p>
              </div>
            </div>

            <div className="flex items-center gap-4 self-end sm:self-auto font-mono text-xs">
              <div className="text-right">
                <span className="text-[#8492A6] text-[10px] block">Violations Flagged</span>
                <span className={`font-bold ${rule.violationCount > 0 ? 'text-[#FF5268]' : 'text-[#00D6A0]'}`}>
                  {rule.violationCount} recorded
                </span>
              </div>

              <button
                onClick={() => onDeleteRule(rule.id)}
                className="p-2 rounded-xl text-[#8492A6] hover:text-[#FF5268] hover:bg-[#182333]"
                title="Delete rule"
              >
                <Trash2 size={15} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
