import React, { useState } from 'react';
import { Calculator, AlertTriangle, ShieldCheck, TrendingUp, Sparkles, Zap } from 'lucide-react';
import { formatCurrency, simulateMartingale } from '../../utils/calculations';

import { LossRecoveryPlanner } from '../ui/LossRecoveryPlanner';

export function RiskCalculatorView() {
  const [activeCalculator, setActiveCalculator] = useState<'binary' | 'recovery' | 'cfd'>('binary');

  // Forex Calculator State
  const [balance, setBalance] = useState<number>(1000);
  const [riskPercent, setRiskPercent] = useState<number>(2.0);
  const [entryPrice, setEntryPrice] = useState<number>(1.0850);
  const [stopPrice, setStopPrice] = useState<number>(1.0825);
  const [targetPrice, setTargetPrice] = useState<number>(1.0910);
  const [pointValue, setPointValue] = useState<number>(100000); // EURUSD
  const [assetPreset, setAssetPreset] = useState<'EURUSD' | 'GBPUSD' | 'USDJPY' | 'AUDUSD' | 'CUSTOM'>('EURUSD');

  // Binary Options / Quotex Martingale State
  const [initialBet, setInitialBet] = useState<number>(15);
  const [payoutRate, setPayoutRate] = useState<number>(90);
  const [multiplier, setMultiplier] = useState<number>(2.2);
  const [martingaleSteps, setMartingaleSteps] = useState<number>(5);

  // Asset preset helper
  const handlePresetChange = (preset: 'EURUSD' | 'GBPUSD' | 'USDJPY' | 'AUDUSD' | 'CUSTOM') => {
    setAssetPreset(preset as any);
    if (preset === 'EURUSD') {
      setEntryPrice(1.0850);
      setStopPrice(1.0825);
      setTargetPrice(1.0910);
      setPointValue(100000);
    } else if (preset === 'GBPUSD') {
      setEntryPrice(1.2980);
      setStopPrice(1.2950);
      setTargetPrice(1.3040);
      setPointValue(100000);
    } else if (preset === 'USDJPY') {
      setEntryPrice(152.40);
      setStopPrice(152.10);
      setTargetPrice(153.00);
      setPointValue(1000);
    } else if (preset === 'AUDUSD') {
      setEntryPrice(0.7015);
      setStopPrice(0.6990);
      setTargetPrice(0.7060);
      setPointValue(100000);
    }
  };

  // CFD Calculations
  const riskAmount = (balance * riskPercent) / 100;
  const stopDistance = Math.abs(entryPrice - stopPrice);
  const targetDistance = Math.abs(targetPrice - entryPrice);
  const riskPerUnit = stopDistance * pointValue;
  const positionSize = riskPerUnit > 0 ? riskAmount / riskPerUnit : 0;
  const potentialLoss = positionSize * riskPerUnit;
  const potentialProfit = positionSize * targetDistance * pointValue;
  const rrRatio = stopDistance > 0 ? targetDistance / stopDistance : 0;

  // Martingale steps
  const martingaleTable = simulateMartingale(initialBet, payoutRate, multiplier, martingaleSteps);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-[#07060A]/90 border border-[#8B5CF6]/25 shadow-xl backdrop-blur-2xl">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#A78BFA]">
            <Calculator size={14} className="text-[#8B5CF6]" />
            <span>QUOTEX MONEY MANAGEMENT & RISK ENGINE</span>
          </div>
          <h1 className="text-xl lg:text-2xl font-black text-white mt-1 tracking-tight">
            Quotex Position Sizing & Money Management
          </h1>
          <p className="text-xs text-[#A78BFA]/80 mt-0.5">
            Fixed-time expiration payout calculations, Martingale risk simulation, and step recovery planner
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex items-center bg-[#0D0B14] p-1 rounded-xl border border-[#8B5CF6]/25 text-xs font-mono">
          <button
            onClick={() => setActiveCalculator('binary')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
              activeCalculator === 'binary'
                ? 'bg-[#8B5CF6] text-white shadow-[0_0_12px_rgba(139,92,246,0.5)]'
                : 'text-[#A78BFA] hover:text-white'
            }`}
          >
            Quotex Binary & Martingale Model
          </button>
          <button
            onClick={() => setActiveCalculator('recovery')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
              activeCalculator === 'recovery'
                ? 'bg-[#10B981] text-[#07060A] shadow-[0_0_12px_rgba(16,185,129,0.5)]'
                : 'text-[#A78BFA] hover:text-white'
            }`}
          >
            Loss Recovery Planner
          </button>
        </div>
      </div>

      {activeCalculator === 'recovery' ? (
        <LossRecoveryPlanner currentDrawdown={150} currentBalance={balance} />
      ) : activeCalculator === 'cfd' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Inputs Column */}
          <div className="lg:col-span-2 trade-card rounded-2xl p-6 border border-[#1E293B] space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-[#1E293B]">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <ShieldCheck size={16} className="text-[#3987FF]" />
                Position Parameters & Instrument Specs
              </h3>
              {/* Preset buttons */}
              <div className="flex items-center gap-1 text-[11px] font-mono">
                {(['EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD', 'CUSTOM'] as const).map((p) => (
                  <button
                    key={p}
                    onClick={() => handlePresetChange(p)}
                    className={`px-2 py-0.5 rounded font-bold transition-all ${
                      assetPreset === p
                        ? 'bg-[#3987FF] text-white'
                        : 'bg-[#080B12] text-[#8492A6] hover:text-white border border-[#1E293B]'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-[#8492A6] block mb-1">Account Equity / Balance ($)</label>
                <input
                  type="number"
                  value={balance}
                  onChange={(e) => setBalance(Number(e.target.value))}
                  className="w-full bg-[#080B12] border border-[#222E40] rounded-xl px-3 py-2 text-xs font-mono font-bold text-white outline-none"
                />
              </div>
              <div>
                <label className="text-xs text-[#8492A6] block mb-1">Risk Percentage (%)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    step="0.1"
                    value={riskPercent}
                    onChange={(e) => setRiskPercent(Number(e.target.value))}
                    className="w-full bg-[#080B12] border border-[#222E40] rounded-xl px-3 py-2 text-xs font-mono font-bold text-white outline-none"
                  />
                  <div className="flex gap-1">
                    {[0.5, 1.0, 1.5, 2.0].map((pct) => (
                      <button
                        key={pct}
                        type="button"
                        onClick={() => setRiskPercent(pct)}
                        className={`px-2 py-1.5 rounded-lg text-[10px] font-mono font-bold ${
                          riskPercent === pct ? 'bg-[#3987FF] text-white' : 'bg-[#182333] text-[#8492A6]'
                        }`}
                      >
                        {pct}%
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono">
              <div>
                <label className="text-xs text-[#8492A6] block mb-1">Planned Entry Price</label>
                <input
                  type="number"
                  step="any"
                  value={entryPrice}
                  onChange={(e) => setEntryPrice(Number(e.target.value))}
                  className="w-full bg-[#080B12] border border-[#222E40] rounded-xl px-3 py-2 text-xs text-white outline-none font-bold"
                />
              </div>
              <div>
                <label className="text-xs text-[#8492A6] block mb-1">Stop Loss Price</label>
                <input
                  type="number"
                  step="any"
                  value={stopPrice}
                  onChange={(e) => setStopPrice(Number(e.target.value))}
                  className="w-full bg-[#080B12] border border-[#222E40] rounded-xl px-3 py-2 text-xs text-[#FF5268] outline-none font-bold"
                />
              </div>
              <div>
                <label className="text-xs text-[#8492A6] block mb-1">Take Profit Target</label>
                <input
                  type="number"
                  step="any"
                  value={targetPrice}
                  onChange={(e) => setTargetPrice(Number(e.target.value))}
                  className="w-full bg-[#080B12] border border-[#222E40] rounded-xl px-3 py-2 text-xs text-[#00D6A0] outline-none font-bold"
                />
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#080B12] border border-[#1E293B] flex items-center justify-between text-xs font-mono">
              <span className="text-[#8492A6]">Point Value / Multiplier:</span>
              <span className="text-slate-200 font-bold">
                ${pointValue} per unit/point
              </span>
            </div>
          </div>

          {/* Outputs Column */}
          <div className="trade-card rounded-2xl p-6 border border-[#1E293B] flex flex-col justify-between space-y-4">
            <div>
              <span className="text-xs font-bold text-[#8492A6] uppercase tracking-wider block mb-3 pb-2 border-b border-[#1E293B]">
                Position Sizing Outputs
              </span>

              <div className="space-y-4 font-mono">
                <div className="p-4 rounded-xl bg-[#080B12] border border-[#1E293B]">
                  <span className="text-[11px] text-[#8492A6] block">Recommended Size:</span>
                  <div className="text-3xl font-black text-[#3987FF] mt-1">
                    {positionSize.toFixed(2)} <span className="text-xs font-normal text-slate-400">Contracts / Lots</span>
                  </div>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#080B12]">
                    <span className="text-[#8492A6]">Max Risk Amount:</span>
                    <span className="font-bold text-[#FF5268]">-${formatCurrency(riskAmount)}</span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#080B12]">
                    <span className="text-[#8492A6]">Potential Profit:</span>
                    <span className="font-bold text-[#00D6A0]">+{formatCurrency(potentialProfit)}</span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#080B12]">
                    <span className="text-[#8492A6]">Reward-to-Risk (R:R):</span>
                    <span className="font-bold text-white">{rrRatio.toFixed(2)} : 1 ({rrRatio.toFixed(2)}R)</span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#080B12]">
                    <span className="text-[#8492A6]">Stop Distance:</span>
                    <span className="font-bold text-slate-300">{stopDistance.toFixed(2)} points</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-[#00D6A0] font-mono flex items-center gap-1.5 p-2 rounded-lg bg-[#00D6A0]/10 border border-[#00D6A0]/20">
              <ShieldCheck size={14} />
              <span>Never adjust stop loss mid-trade</span>
            </div>
          </div>
        </div>
      ) : (
        /* CALCULATOR 2: QUOTEX BINARY OPTIONS & MARTINGALE SIMULATOR */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="trade-card rounded-2xl p-6 border border-[#1E293B] space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2 pb-3 border-b border-[#1E293B]">
              <Zap size={16} className="text-[#9875FF]" />
              Quotex Binary Money Management Inputs
            </h3>

            <div>
              <label className="text-xs text-[#8492A6] block mb-1">Base Investment ($)</label>
              <input
                type="number"
                value={initialBet}
                onChange={(e) => setInitialBet(Number(e.target.value))}
                className="w-full bg-[#080B12] border border-[#222E40] rounded-xl px-3 py-2 text-xs font-mono font-bold text-white outline-none"
              />
            </div>

            <div>
              <label className="text-xs text-[#8492A6] block mb-1">Average Payout Rate (%)</label>
              <div className="flex items-center gap-1">
                {[80, 85, 87, 90, 95].map((pct) => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => setPayoutRate(pct)}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-mono font-bold ${
                      payoutRate === pct ? 'bg-[#9875FF] text-white' : 'bg-[#080B12] text-[#8492A6]'
                    }`}
                  >
                    {pct}%
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs text-[#8492A6] block mb-1">Martingale Multiplier (Standard 2.2x)</label>
              <input
                type="number"
                step="0.1"
                value={multiplier}
                onChange={(e) => setMultiplier(Number(e.target.value))}
                className="w-full bg-[#080B12] border border-[#222E40] rounded-xl px-3 py-2 text-xs font-mono text-white outline-none font-bold"
              />
            </div>

            {/* Risk Warning Box */}
            <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs leading-relaxed space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-[#FF5268]">
                <AlertTriangle size={14} />
                <span>Martingale Risk Warning</span>
              </div>
              <p className="text-[11px] text-red-200">
                Martingale increases consecutive bet sizes exponentially. A 4-trade losing streak risks <strong>${martingaleTable[3]?.cumLoss || 0}</strong> to recover a small base win.
              </p>
            </div>
          </div>

          {/* Simulator Table */}
          <div className="lg:col-span-2 trade-card rounded-2xl p-6 border border-[#1E293B]">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#1E293B]">
              <h3 className="text-sm font-bold text-white">
                Step-by-Step Recovery Matrix ({payoutRate}% Payout)
              </h3>
              <span className="text-xs text-[#8492A6] font-mono">
                Break-even win rate: ~54%
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-[#080B12] text-[#64748B] uppercase text-[10px] border-b border-[#1E293B]">
                  <tr>
                    <th className="p-3">Martingale Step</th>
                    <th className="p-3">Bet Amount ($)</th>
                    <th className="p-3 text-right">Cumulative Lost</th>
                    <th className="p-3 text-right">Win Return</th>
                    <th className="p-3 text-right">Net Profit on Win</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E293B]">
                  {martingaleTable.map((row) => (
                    <tr key={row.step} className="hover:bg-[#182333]/50">
                      <td className="p-3 font-bold text-white">
                        Step {row.step} {row.step === 1 ? '(Base)' : ''}
                      </td>
                      <td className="p-3 font-bold text-[#3987FF]">
                        ${row.bet}
                      </td>
                      <td className="p-3 text-right text-[#FF5268]">
                        -${row.cumLoss}
                      </td>
                      <td className="p-3 text-right text-slate-300">
                        +${row.winProfit}
                      </td>
                      <td className="p-3 text-right font-black text-[#00D6A0]">
                        +${row.netProfitOnWin}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
