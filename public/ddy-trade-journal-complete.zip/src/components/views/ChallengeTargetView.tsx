import React, { useState } from 'react';
import { ChallengeDay, Trade } from '../../types/trade';
import { 
  Trophy, 
  Target, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Sparkles, 
  Printer, 
  Download, 
  RefreshCw, 
  Image as ImageIcon,
  Flame,
  ArrowRight,
  TrendingUp,
  ShieldCheck
} from 'lucide-react';
import { formatCurrency } from '../../utils/calculations';
import confetti from 'canvas-confetti';

interface ChallengeTargetViewProps {
  challengeDays: ChallengeDay[];
  onUpdateDay: (dayNum: number, updates: Partial<ChallengeDay>) => void;
  todayTrades: Trade[];
}

export function ChallengeTargetView({
  challengeDays,
  onUpdateDay,
  todayTrades,
}: ChallengeTargetViewProps) {
  const [showOriginalImage, setShowOriginalImage] = useState(false);
  const [editingDay, setEditingDay] = useState<number | null>(null);
  const [editActual, setEditActual] = useState<string>('');
  const [editNotes, setEditNotes] = useState<string>('');

  // Calculate overall metrics
  const achievedDays = challengeDays.filter(d => d.status === 'achieved');
  const missedDays = challengeDays.filter(d => d.status === 'missed');
  const inProgressDay = challengeDays.find(d => d.status === 'in_progress') || challengeDays[4];

  // Current capital estimation
  const currentAccumulatedProfit = challengeDays.reduce((acc, d) => {
    if (d.status === 'achieved') return acc + (d.actualProfit ?? d.profitTarget);
    if (d.status === 'in_progress') return acc + (d.actualProfit ?? 0);
    return acc;
  }, 0);
  const currentEquity = 100 + currentAccumulatedProfit;
  const progressPercent = Math.min(100, Math.max(2, (currentEquity / 5000) * 100));

  const handleToggleStatus = (day: ChallengeDay) => {
    let nextStatus: ChallengeDay['status'] = 'achieved';
    if (day.status === 'achieved') nextStatus = 'missed';
    else if (day.status === 'missed') nextStatus = 'in_progress';
    else if (day.status === 'in_progress') nextStatus = 'pending';
    else nextStatus = 'achieved';

    if (nextStatus === 'achieved') {
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 },
          colors: ['#10B981', '#8B5CF6', '#C084FC', '#F59E0B'],
        });
      } catch (e) {}
    }

    onUpdateDay(day.day, {
      status: nextStatus,
      actualProfit: nextStatus === 'achieved' ? (day.actualProfit ?? day.profitTarget) : nextStatus === 'missed' ? 0 : day.actualProfit,
    });
  };

  const handleSaveEdit = (dayNum: number) => {
    onUpdateDay(dayNum, {
      actualProfit: parseFloat(editActual) || 0,
      notes: editNotes,
    });
    setEditingDay(null);
  };

  const handleExportCsv = () => {
    const headers = ['Day', 'Starting Balance', 'Profit Target', 'Expected Balance', 'Lot Size', 'Status', 'Actual Profit', 'Notes'];
    const rows = challengeDays.map(d => [
      d.day,
      d.startingBalance,
      d.profitTarget,
      d.expectedBalance,
      `"${d.lotSize}"`,
      d.status.toUpperCase(),
      d.actualProfit ?? '',
      `"${d.notes || ''}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'tradepath_30days_challenge_schedule.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Ultra-Premium Glassmorphic Hero Banner */}
      <div className="p-6 sm:p-8 rounded-3xl trade-card relative overflow-hidden shadow-2xl border border-[#8B5CF6]/25">
        {/* Subtle background ambient purple watermark */}
        <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-5 pointer-events-none select-none text-9xl font-black font-mono text-[#C084FC]">
          $5000
        </div>

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2.5">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#8B5CF6] via-[#A78BFA] to-[#C084FC] p-0.5 flex items-center justify-center shadow-[0_0_20px_rgba(139,92,246,0.45)]">
                <div className="w-full h-full bg-[#07060A] rounded-[14px] flex items-center justify-center font-black text-xs text-[#C084FC] tracking-wider">
                  VTA
                </div>
              </div>
              <span className="text-xs font-mono font-bold tracking-widest text-[#A78BFA] uppercase flex items-center gap-2">
                <span>30 DAYS TRADING CHALLENGE JOURNAL ($100 TO $5K)</span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse"></span>
              </span>
            </div>

            {/* Main "$100 → $5,000" header with elegant purple gradient text with soft glow */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight font-mono flex items-center gap-3 pt-1">
              <span className="header-purple-glow">
                $100
              </span>
              <ArrowRight size={32} className="text-[#C084FC] animate-pulse-subtle" />
              <span className="bg-gradient-to-r from-[#C084FC] via-[#A78BFA] to-[#10B981] bg-clip-text text-transparent drop-shadow-[0_0_22px_rgba(16,185,129,0.4)]">
                $5,000
              </span>
            </h1>

            <p className="text-xs text-[#94A3B8] max-w-xl font-sans leading-relaxed">
              Strict mathematical compounding plan with lot size discipline and Quotex binary option investment rules. Complete daily profit targets with zero over-leveraging.
            </p>
          </div>

          {/* Quick Action Controls with Buttery Hover Animations */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setShowOriginalImage(!showOriginalImage)}
              className="px-4 py-2.5 rounded-2xl btn-glass-subtle text-xs font-bold flex items-center gap-2"
            >
              <ImageIcon size={15} className="text-[#A78BFA]" />
              <span>{showOriginalImage ? 'Hide Reference' : 'View Target Sheet'}</span>
            </button>

            <button
              onClick={handleExportCsv}
              className="px-4 py-2.5 rounded-2xl btn-glass-subtle text-xs font-bold flex items-center gap-2"
            >
              <Download size={15} className="text-[#10B981]" />
              <span>Download CSV</span>
            </button>

            <button
              onClick={() => window.print()}
              className="px-4 py-2.5 rounded-2xl btn-premium-purple text-xs font-bold flex items-center gap-2"
            >
              <Printer size={15} />
              <span>Print Plan</span>
            </button>
          </div>
        </div>

        {/* Challenge Progress Bar with Shimmer Light Sweep */}
        <div className="mt-6 pt-5 border-t border-[#8B5CF6]/15 space-y-2.5">
          <div className="flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-2">
              <Flame size={15} className="text-[#F59E0B] fill-[#F59E0B]" />
              <span className="text-white font-bold">Current Standing: {formatCurrency(currentEquity)}</span>
              <span className="text-[#94A3B8]">({achievedDays.length} of 30 Days Achieved)</span>
            </div>
            <span className="text-[#10B981] font-bold">Goal: $5,000.00 ({progressPercent.toFixed(1)}%)</span>
          </div>

          {/* Shimmer sweep container */}
          <div className="h-3.5 w-full bg-[#07060A]/90 rounded-full overflow-hidden border border-[#8B5CF6]/25 p-0.5 shadow-inner">
            <div
              style={{ width: `${progressPercent}%` }}
              className="h-full rounded-full bg-gradient-to-r from-[#8B5CF6] via-[#C084FC] to-[#10B981] transition-all duration-700 shadow-[0_0_16px_rgba(192,132,252,0.6)] progress-sweep"
            />
          </div>

          {/* Milestone checkpoints with desaturated champagne accents */}
          <div className="grid grid-cols-4 gap-2 pt-1 text-[10px] font-mono text-[#94A3B8]">
            <div className="text-left text-[#A78BFA]">● Day 1: $100 Start</div>
            <div className="text-center text-[#C084FC]">● Day 14: $500 Checkpoint</div>
            <div className="text-center text-[#FCD34D]">● Day 23: $1,640 Acceleration</div>
            <div className="text-right text-[#10B981] font-bold">★ Day 30: $5,000 Grand Goal</div>
          </div>
        </div>
      </div>

      {/* Original Image Reference Lightbox */}
      {showOriginalImage && (
        <div className="p-5 rounded-2xl trade-card border border-[#8B5CF6]/40 shadow-2xl space-y-3 animate-in fade-in zoom-in-95 duration-200">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-200 flex items-center gap-2">
              <ImageIcon size={15} className="text-[#C084FC]" />
              Original Reference: 30 Days Trading Challenge Target Journal
            </span>
            <button onClick={() => setShowOriginalImage(false)} className="text-[#94A3B8] hover:text-white transition-colors">
              Close
            </button>
          </div>
          <div className="flex justify-center p-3 bg-[#07060A] rounded-xl border border-[#8B5CF6]/20">
            <img
              src="/assets/aistudio/Screenshot_2026-10-30_at_8.36.09_AM_964ca338.png"
              alt="30 Days Trading Challenge Target Journal"
              className="max-h-96 object-contain rounded-lg border border-[#8B5CF6]/30 shadow-2xl"
            />
          </div>
        </div>
      )}

      {/* 30-Day Master Target Table */}
      <div className="trade-card rounded-2xl overflow-hidden border border-[#8B5CF6]/20 shadow-2xl">
        <div className="p-4 bg-[#0E0A1A]/80 border-b border-[#8B5CF6]/20 flex flex-wrap items-center justify-between gap-3 backdrop-blur-xl">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Target size={16} className="text-[#10B981]" />
              30-Day Compounding Target Schedule
            </h2>
            <p className="text-xs text-[#94A3B8] mt-0.5">
              Click any status button to toggle YES (Achieved), NO (Missed), or IN PROGRESS. Click actual profit to edit.
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#10B981] shadow-[0_0_8px_#10B981]"></span>
              <span className="text-slate-300">{achievedDays.length} Achieved</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#F43F5E] shadow-[0_0_8px_#F43F5E]"></span>
              <span className="text-slate-300">{missedDays.length} Missed</span>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-[#8B5CF6]/15 bg-[#0B0816]/70 text-[#94A3B8] text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4 font-semibold">DAY</th>
                <th className="py-3 px-4 font-semibold">BALANCE</th>
                <th className="py-3 px-4 font-semibold">PROFIT TARGET</th>
                <th className="py-3 px-4 font-semibold">EXPECTED BALANCE</th>
                <th className="py-3 px-4 font-semibold">LOT SIZE / QUOTEX</th>
                <th className="py-3 px-4 font-semibold text-center">ACHIEVED YES/NO</th>
                <th className="py-3 px-4 font-semibold text-right">ACTUAL REALIZED</th>
                <th className="py-3 px-4 font-semibold">NOTES</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#8B5CF6]/10 text-xs">
              {challengeDays.map((d) => {
                const isAchieved = d.status === 'achieved';
                const isMissed = d.status === 'missed';
                const isInProgress = d.status === 'in_progress';

                return (
                  <tr
                    key={d.day}
                    className={`transition-all duration-200 ${
                      isInProgress
                        ? 'bg-[#8B5CF6]/15 font-bold shadow-[inset_0_0_12px_rgba(139,92,246,0.15)]'
                        : isAchieved
                        ? 'bg-[#10B981]/5 hover:bg-[#10B981]/10'
                        : isMissed
                        ? 'bg-[#F43F5E]/5 hover:bg-[#F43F5E]/10'
                        : 'hover:bg-[#161028]/60'
                    }`}
                  >
                    {/* Day */}
                    <td className="py-3 px-4 font-bold text-white">
                      <div className="flex items-center gap-2">
                        <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs transition-all ${
                          isInProgress
                            ? 'bg-[#8B5CF6] text-white shadow-[0_0_12px_#8B5CF6]'
                            : isAchieved
                            ? 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/30'
                            : 'bg-[#161028] text-slate-400 border border-[#8B5CF6]/20'
                        }`}>
                          {d.day}
                        </span>
                        {isInProgress && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 text-[#C084FC] status-pill-glow">
                            Active
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Starting Balance */}
                    <td className="py-3 px-4 text-slate-300">
                      ${d.startingBalance.toLocaleString()}
                    </td>

                    {/* Profit Target */}
                    <td className="py-3 px-4 font-bold text-[#10B981]">
                      +${d.profitTarget}
                    </td>

                    {/* Expected Balance */}
                    <td className="py-3 px-4 font-extrabold text-white">
                      ${d.expectedBalance.toLocaleString()}
                    </td>

                    {/* Lot Size / Quotex Bet */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        <span className="px-2 py-0.5 rounded-md bg-[#161028] border border-[#8B5CF6]/25 text-white font-bold">
                          {d.lotSize}
                        </span>
                        <span className="text-[10px] text-[#94A3B8]">
                          (Quotex ${d.quotexInvestment})
                        </span>
                      </div>
                    </td>

                    {/* Achieved YES/NO Button with Rich Glass Effect and Buttery Animations */}
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => handleToggleStatus(d)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 active:scale-95 hover:scale-105 ${
                          isAchieved
                            ? 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/45 shadow-[0_0_16px_rgba(16,185,129,0.35)] backdrop-blur-md'
                            : isMissed
                            ? 'bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/45 shadow-[0_0_16px_rgba(239,68,68,0.35)] backdrop-blur-md'
                            : isInProgress
                            ? 'bg-[#8B5CF6]/25 text-[#C084FC] border border-[#8B5CF6]/50 shadow-[0_0_16px_rgba(139,92,246,0.4)] status-pill-glow backdrop-blur-md'
                            : 'bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/30 hover:bg-[#F59E0B]/25 backdrop-blur-md'
                        }`}
                        title="Click to cycle status"
                      >
                        {isAchieved ? (
                          <>
                            <CheckCircle2 size={13} />
                            <span>YES</span>
                          </>
                        ) : isMissed ? (
                          <>
                            <XCircle size={13} />
                            <span>NO</span>
                          </>
                        ) : isInProgress ? (
                          <>
                            <Clock size={13} />
                            <span>IN PROGRESS</span>
                          </>
                        ) : (
                          <span>PENDING</span>
                        )}
                      </button>
                    </td>

                    {/* Actual Realized */}
                    <td className="py-3 px-4 text-right">
                      {editingDay === d.day ? (
                        <div className="flex items-center justify-end gap-1">
                          <input
                            type="number"
                            value={editActual}
                            onChange={(e) => setEditActual(e.target.value)}
                            className="w-16 bg-[#07060A] border border-[#8B5CF6] rounded p-1 text-xs text-white outline-none ring-1 ring-[#8B5CF6]"
                            autoFocus
                          />
                          <button onClick={() => handleSaveEdit(d.day)} className="text-[#10B981] text-xs font-bold">✓</button>
                        </div>
                      ) : (
                        <span
                          onClick={() => {
                            setEditingDay(d.day);
                            setEditActual(String(d.actualProfit ?? d.profitTarget));
                            setEditNotes(d.notes || '');
                          }}
                          className={`cursor-pointer hover:underline font-bold transition-colors ${
                            d.actualProfit !== undefined && d.actualProfit > 0
                              ? 'text-[#10B981]'
                              : d.actualProfit !== undefined && d.actualProfit <= 0
                              ? 'text-[#F43F5E]'
                              : 'text-slate-500 hover:text-slate-300'
                          }`}
                          title="Click to edit actual profit"
                        >
                          {d.actualProfit !== undefined ? `+${formatCurrency(d.actualProfit)}` : '—'}
                        </span>
                      )}
                    </td>

                    {/* Notes */}
                    <td className="py-3 px-4 text-slate-400 text-[11px] truncate max-w-xs font-sans">
                      {d.notes || <span className="text-[#64748B] italic">No notes</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
