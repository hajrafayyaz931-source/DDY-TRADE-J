import React, { useState } from 'react';
import { Trade, TradeEmotion } from '../../types/trade';
import { 
  HeartHandshake, 
  AlertTriangle, 
  ShieldCheck, 
  Flame, 
  BrainCircuit, 
  TrendingDown, 
  TrendingUp,
  Sparkles,
  Smile,
  Frown,
  CheckCircle2,
  AlertOctagon,
  Zap
} from 'lucide-react';
import { formatCurrency } from '../../utils/calculations';
import { MistakeTagsCloud } from '../ui/MistakeTagsCloud';
import { StreakProtectorWidget } from '../ui/StreakProtectorWidget';

interface PsychologyViewProps {
  trades: Trade[];
}

const EMOTIONAL_STATES: TradeEmotion[] = [
  'Calm',
  'Confident',
  'Disciplined',
  'Fear',
  'FOMO',
  'Revenge',
  'Greed',
  'Impatient',
  'Frustrated',
  'Anxious',
  'Boredom',
];

export function PsychologyView({ trades }: PsychologyViewProps) {
  const [currentMood, setCurrentMood] = useState<TradeEmotion>('Calm');
  const [moodNotes, setMoodNotes] = useState('');
  const [loggedToday, setLoggedToday] = useState(false);

  // Aggregate stats by emotion
  const emotionStats: Record<string, { count: number; pnl: number; wins: number; losses: number; rTotal: number }> = {};
  
  trades.forEach(t => {
    const em = t.emotion || 'Calm';
    if (!emotionStats[em]) {
      emotionStats[em] = { count: 0, pnl: 0, wins: 0, losses: 0, rTotal: 0 };
    }
    emotionStats[em].count++;
    emotionStats[em].pnl += t.pnl;
    if (t.pnl > 0) emotionStats[em].wins++;
    else if (t.pnl < 0) emotionStats[em].losses++;
    if (t.rMultiple !== undefined) emotionStats[em].rTotal += t.rMultiple;
  });

  const sortedEmotions = Object.entries(emotionStats).sort((a, b) => b[1].pnl - a[1].pnl);

  // Cost of emotional trades (FOMO + Revenge + Impatient + Greed)
  const emotionalTrades = trades.filter(t => 
    t.emotion === 'FOMO' || t.emotion === 'Revenge' || t.emotion === 'Impatient' || t.emotion === 'Greed' || t.emotion === 'Frustrated'
  );
  const emotionalLossTotal = emotionalTrades.reduce((acc, t) => acc + (t.pnl < 0 ? t.pnl : 0), 0);
  const disciplinedTrades = trades.filter(t => 
    t.emotion === 'Calm' || t.emotion === 'Disciplined' || t.emotion === 'Confident'
  );
  const disciplinedPnl = disciplinedTrades.reduce((acc, t) => acc + t.pnl, 0);
  const disciplinedWinRate = disciplinedTrades.length > 0 
    ? Math.round((disciplinedTrades.filter(t => t.pnl > 0).length / disciplinedTrades.length) * 100) 
    : 0;

  // Rule compliance analysis
  const perfectRulesTrades = trades.filter(t => (t.rulesFollowed || 0) >= (t.totalRules || 5));
  const brokenRulesTrades = trades.filter(t => (t.rulesFollowed || 0) < (t.totalRules || 5));
  const perfectRulesPnl = perfectRulesTrades.reduce((acc, t) => acc + t.pnl, 0);
  const brokenRulesPnl = brokenRulesTrades.reduce((acc, t) => acc + t.pnl, 0);

  const handleSaveMood = () => {
    setLoggedToday(true);
    setTimeout(() => setLoggedToday(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-5 rounded-2xl bg-[#07060A]/90 border border-[#8B5CF6]/25 shadow-xl backdrop-blur-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#A78BFA]">
            <HeartHandshake size={14} className="text-[#8B5CF6]" />
            <span>BEHAVIORAL TRADING INTELLIGENCE</span>
          </div>
          <h1 className="text-xl lg:text-2xl font-black text-white mt-1 tracking-tight">
            Trading Psychology & Discipline Engine
          </h1>
          <p className="text-xs text-[#A78BFA]/80 mt-0.5">
            Identify emotional leaks, calculate the dollar cost of FOMO/Revenge, and track daily mindset
          </p>
        </div>

        <span className="text-xs px-3.5 py-1.5 rounded-full bg-[#8B5CF6]/20 text-[#C084FC] font-mono font-bold border border-[#8B5CF6]/35 shadow-[0_0_12px_rgba(139,92,246,0.3)] self-start sm:self-auto">
          Current State: {currentMood}
        </span>
      </div>

      {/* Streak Protector & Mistake Tags Cloud */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <StreakProtectorWidget trades={trades} />
        <MistakeTagsCloud trades={trades} />
      </div>

      {/* Daily Mindset & Emotional State Logger */}
      <div className="trade-card rounded-2xl p-5 border border-[#8B5CF6]/25 bg-[#07060A]/85 backdrop-blur-2xl shadow-xl">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#8B5CF6]/20">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Sparkles size={16} className="text-[#C084FC]" />
            Live Pre-Session Mindset Logger
          </h3>
          <span className="text-xs text-[#A78BFA] font-mono">Calibrate before entering orders</span>
        </div>

        <div className="space-y-3">
          <div className="flex flex-wrap gap-2">
            {EMOTIONAL_STATES.map((em) => {
              const isSelected = currentMood === em;
              const isPositive = em === 'Calm' || em === 'Disciplined' || em === 'Confident';

              return (
                <button
                  key={em}
                  onClick={() => setCurrentMood(em)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all ${
                    isSelected
                      ? isPositive
                        ? 'bg-[#10B981] text-white shadow-[0_0_14px_rgba(16,185,129,0.5)]'
                        : 'bg-[#EF4444] text-white shadow-[0_0_14px_rgba(239,68,68,0.5)]'
                      : 'bg-[#0D0B14] text-[#A78BFA] border border-[#8B5CF6]/20 hover:border-[#8B5CF6]/40 hover:text-white'
                  }`}
                >
                  {em}
                </button>
              );
            })}
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
            <input
              type="text"
              value={moodNotes}
              onChange={e => setMoodNotes(e.target.value)}
              placeholder="Session mindset notes (e.g. Well-rested, waiting for key level retest, no rush)..."
              className="flex-1 w-full bg-[#0D0B14] border border-[#8B5CF6]/25 rounded-xl px-3 py-2 text-xs text-white outline-none font-mono"
            />
            <button
              onClick={handleSaveMood}
              className="btn-premium-purple px-5 py-2 rounded-xl text-xs font-bold text-white whitespace-nowrap flex items-center gap-2"
            >
              <CheckCircle2 size={14} />
              <span>{loggedToday ? 'Mindset Saved!' : 'Log Mental State'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Exact Dollar Cost of Emotional Leaks */}
      <div className="p-6 rounded-2xl bg-[#07060A]/90 border border-[#EF4444]/35 shadow-2xl backdrop-blur-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-mono text-[#EF4444] font-bold">
            <AlertTriangle size={16} className="text-[#EF4444]" />
            <span>MEASURED COST OF EMOTIONAL LEAKS</span>
          </div>
          <h2 className="text-3xl font-black font-mono text-white">
            -${Math.abs(emotionalLossTotal).toFixed(2)}
          </h2>
          <p className="text-xs text-[#A78BFA] max-w-md">
            Direct realized losses accumulated exclusively when taking entries under FOMO, Revenge, Greed, or Impatience.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4 text-center font-mono w-full md:w-auto">
          <div className="p-3.5 rounded-xl bg-[#0D0B14] border border-[#10B981]/30">
            <span className="text-[10px] text-[#A78BFA] block uppercase">Calm / Disciplined PnL</span>
            <span className="text-base font-extrabold text-[#10B981]">
              +{formatCurrency(disciplinedPnl)}
            </span>
            <span className="text-[10px] text-[#A78BFA]/70 block mt-0.5">
              {disciplinedTrades.length} trades ({disciplinedWinRate}% WR)
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-[#0D0B14] border border-[#EF4444]/30">
            <span className="text-[10px] text-[#A78BFA] block uppercase">Emotional Win Rate</span>
            <span className="text-base font-extrabold text-[#EF4444]">
              {emotionalTrades.length > 0 ? Math.round((emotionalTrades.filter(t => t.pnl > 0).length / emotionalTrades.length) * 100) : 0}%
            </span>
            <span className="text-[10px] text-[#A78BFA]/70 block mt-0.5">
              {emotionalTrades.length} emotional executions
            </span>
          </div>
        </div>
      </div>

      {/* Rule Compliance Impact Matrix */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="trade-card rounded-2xl p-5 border border-[#10B981]/30 bg-[#07060A]/85 backdrop-blur-2xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-white flex items-center gap-2">
              <ShieldCheck size={16} className="text-[#10B981]" />
              100% Rule Compliance Outcome
            </span>
            <span className="text-xs px-2 py-0.5 rounded bg-[#10B981]/20 text-[#10B981] font-mono font-bold">
              {perfectRulesTrades.length} Trades
            </span>
          </div>
          <div className="text-2xl font-black font-mono text-[#10B981]">
            +{formatCurrency(perfectRulesPnl)}
          </div>
          <p className="text-xs text-[#A78BFA]/80 mt-1 font-mono">
            Every trade where all setup, risk, and exit rules were strictly observed.
          </p>
        </div>

        <div className="trade-card rounded-2xl p-5 border border-[#EF4444]/30 bg-[#07060A]/85 backdrop-blur-2xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-white flex items-center gap-2">
              <AlertOctagon size={16} className="text-[#EF4444]" />
              Broken Rules Penalty
            </span>
            <span className="text-xs px-2 py-0.5 rounded bg-[#EF4444]/20 text-[#EF4444] font-mono font-bold">
              {brokenRulesTrades.length} Trades
            </span>
          </div>
          <div className="text-2xl font-black font-mono text-[#EF4444]">
            {formatCurrency(brokenRulesPnl)}
          </div>
          <p className="text-xs text-[#A78BFA]/80 mt-1 font-mono">
            Financial damage caused by bypassing checklist rules or jumping the gun.
          </p>
        </div>
      </div>

      {/* Emotion vs Performance Table */}
      <div className="trade-card rounded-2xl p-6 border border-[#8B5CF6]/25 bg-[#07060A]/85 backdrop-blur-2xl">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#8B5CF6]/20">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <BrainCircuit size={16} className="text-[#8B5CF6]" />
            Performance Breakdown by Emotional State
          </h3>
          <span className="text-xs text-[#A78BFA] font-mono">
            Direct Behavioral Correlation
          </span>
        </div>

        <div className="space-y-3">
          {sortedEmotions.map(([emotionName, data]) => {
            const winRate = data.count > 0 ? Math.round((data.wins / data.count) * 100) : 0;
            const isPos = data.pnl >= 0;
            const isDisciplined = emotionName === 'Calm' || emotionName === 'Disciplined' || emotionName === 'Confident';

            return (
              <div
                key={emotionName}
                className="p-4 rounded-xl bg-[#0D0B14]/80 border border-[#8B5CF6]/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-[#8B5CF6]/40 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className={`px-3 py-1 rounded-xl text-xs font-bold font-mono ${
                    isDisciplined 
                      ? 'bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30 shadow-[0_0_8px_rgba(16,185,129,0.2)]' 
                      : 'bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30 shadow-[0_0_8px_rgba(239,68,68,0.2)]'
                  }`}>
                    {emotionName}
                  </span>
                  <div>
                    <span className="text-xs font-bold text-white">
                      {data.count} Trade{data.count > 1 ? 's' : ''} Executed
                    </span>
                    <span className="text-[11px] text-[#A78BFA]/80 block font-mono">
                      {data.wins} Wins • {data.losses} Losses ({winRate}% Win Rate)
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-6 font-mono text-xs">
                  <div className="text-right">
                    <span className="text-[#A78BFA] text-[10px] block">Net Realized PnL</span>
                    <span className={`text-sm font-extrabold ${isPos ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                      {isPos ? '+' : ''}{formatCurrency(data.pnl)}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
