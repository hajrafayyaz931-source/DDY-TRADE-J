import React, { useState } from 'react';
import { DailyPlaybookPlan, Trade } from '../../types/trade';
import { BookOpen, Check, Target, Compass, Sparkles, BrainCircuit, ShieldAlert, Save } from 'lucide-react';
import { formatCurrency } from '../../utils/calculations';

interface DailyJournalViewProps {
  plan: DailyPlaybookPlan;
  onSavePlan: (updatedPlan: DailyPlaybookPlan) => void;
  trades: Trade[];
}

export function DailyJournalView({ plan, onSavePlan, trades }: DailyJournalViewProps) {
  const [formData, setFormData] = useState<DailyPlaybookPlan>(plan);
  const [saveToast, setSaveToast] = useState(false);

  // Today's trades
  const todayStr = formData.date;
  const todayTrades = trades.filter(t => t.date === todayStr);
  const todayPnl = todayTrades.reduce((acc, t) => acc + t.pnl, 0);
  const todayWins = todayTrades.filter(t => t.pnl > 0).length;

  const handleSave = () => {
    onSavePlan(formData);
    setSaveToast(true);
    setTimeout(() => setSaveToast(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-[#101722] border border-[#1E293B]">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#8492A6]">
            <BookOpen size={14} className="text-[#3987FF]" />
            <span>DAILY PLAYBOOK & SESSION INTENTION</span>
          </div>
          <h1 className="text-xl lg:text-2xl font-extrabold text-white mt-1 tracking-tight">
            Daily Trading Journal
          </h1>
          <p className="text-xs text-[#8492A6] mt-0.5">
            Pre-market preparation, key levels, active watchlist, and end-of-day performance reflection
          </p>
        </div>

        <div className="flex items-center gap-3">
          {saveToast && (
            <span className="text-xs font-bold text-[#00D6A0] flex items-center gap-1 animate-pulse">
              <Check size={14} /> Plan Saved!
            </span>
          )}
          <button
            onClick={handleSave}
            className="px-5 py-2.5 rounded-xl bg-[#3987FF] hover:bg-[#2F74DE] text-white text-xs font-bold flex items-center gap-2 shadow-[0_0_15px_rgba(57,135,255,0.4)] transition-all"
          >
            <Save size={15} />
            <span>Save Daily Playbook</span>
          </button>
        </div>
      </div>

      {/* 3 Step Flow: Pre-Market -> Live Execution -> End of Day */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Step 1: Pre-Market Bias & Key Levels */}
        <div className="lg:col-span-2 space-y-6">
          <div className="trade-card rounded-2xl p-5 border border-[#1E293B] space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#1E293B]">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Compass size={16} className="text-[#3987FF]" />
                1. Pre-Market Bias & Structural Levels
              </h3>
              <span className="text-xs text-[#8492A6] font-mono">{formData.date}</span>
            </div>

            {/* Bias Selector */}
            <div>
              <label className="text-xs text-[#8492A6] block mb-1.5 font-medium">Market Macro Bias</label>
              <div className="grid grid-cols-4 gap-2 text-xs font-bold">
                {(['Bullish', 'Bearish', 'Neutral', 'Mixed'] as const).map((bias) => (
                  <button
                    key={bias}
                    type="button"
                    onClick={() => setFormData({ ...formData, marketBias: bias })}
                    className={`py-2 rounded-xl transition-all border ${
                      formData.marketBias === bias
                        ? bias === 'Bullish'
                          ? 'bg-[#00D6A0] text-[#080B12] font-black border-[#00D6A0]'
                          : bias === 'Bearish'
                          ? 'bg-[#FF5268] text-white font-black border-[#FF5268]'
                          : 'bg-[#3987FF] text-white font-black border-[#3987FF]'
                        : 'bg-[#080B12] text-[#8492A6] border-[#1E293B]'
                    }`}
                  >
                    {bias}
                  </button>
                ))}
              </div>
            </div>

            {/* Support and Resistance Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-[#8492A6] block mb-1 font-medium">Key Support Levels</label>
                <input
                  type="text"
                  value={formData.supportLevels}
                  onChange={(e) => setFormData({ ...formData, supportLevels: e.target.value })}
                  placeholder="NQ 25050, ES 6810, BTC $66,800"
                  className="w-full bg-[#080B12] border border-[#222E40] rounded-xl p-2.5 text-xs font-mono text-white outline-none"
                />
              </div>
              <div>
                <label className="text-xs text-[#8492A6] block mb-1 font-medium">Key Resistance Levels</label>
                <input
                  type="text"
                  value={formData.resistanceLevels}
                  onChange={(e) => setFormData({ ...formData, resistanceLevels: e.target.value })}
                  placeholder="NQ 25280, ES 6865, BTC $68,400"
                  className="w-full bg-[#080B12] border border-[#222E40] rounded-xl p-2.5 text-xs font-mono text-white outline-none"
                />
              </div>
            </div>

            {/* Higher Timeframe Context */}
            <div>
              <label className="text-xs text-[#8492A6] block mb-1 font-medium">Higher Timeframe (HTF) Market Analysis</label>
              <textarea
                value={formData.higherTfAnalysis}
                onChange={(e) => setFormData({ ...formData, higherTfAnalysis: e.target.value })}
                rows={3}
                placeholder="Assess 4H / Daily trends, liquidity pools, news catalysts..."
                className="w-full bg-[#080B12] border border-[#222E40] rounded-xl p-3 text-xs text-white outline-none resize-none"
              />
            </div>
          </div>

          {/* Watchlist & Planned Setups */}
          <div className="trade-card rounded-2xl p-5 border border-[#1E293B] space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#1E293B]">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Target size={16} className="text-[#00D6A0]" />
                2. Active Session Watchlist & Triggers
              </h3>
            </div>

            <div className="space-y-2">
              {formData.watchlist.map((item, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-[#080B12] border border-[#1E293B] flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <span className="font-extrabold text-white font-mono">{item.symbol}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                      item.bias === 'Long' ? 'bg-[#00D6A0]/15 text-[#00D6A0]' : 'bg-[#FF5268]/15 text-[#FF5268]'
                    }`}>
                      {item.bias}
                    </span>
                    <span className="text-slate-300 font-mono">Trigger: {item.keyLevel}</span>
                  </div>
                  <span className="text-[11px] text-[#8492A6] hidden sm:inline">{item.notes}</span>
                </div>
              ))}
            </div>

            {/* Daily Intention Statement */}
            <div>
              <label className="text-xs text-[#8492A6] block mb-1 font-medium">Daily Mental Focus & Intention</label>
              <textarea
                value={formData.dailyIntention}
                onChange={(e) => setFormData({ ...formData, dailyIntention: e.target.value })}
                rows={2}
                placeholder="What is your singular mental commitment today? (e.g. Wait for 5m close, walk away after 2 losses)"
                className="w-full bg-[#080B12] border border-[#222E40] rounded-xl p-3 text-xs text-white outline-none resize-none font-medium text-amber-200"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Risk Limits & End-of-Day Telemetry */}
        <div className="space-y-6">
          {/* Risk Limits */}
          <div className="trade-card rounded-2xl p-5 border border-[#1E293B] space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-[#1E293B] text-sm font-bold text-white">
              <ShieldAlert size={16} className="text-[#FF5268]" />
              <span>Session Risk Boundaries</span>
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#080B12] border border-[#1E293B]">
                <span className="text-[#8492A6]">Max Daily Loss:</span>
                <span className="font-bold text-[#FF5268]">${formData.maxDailyLoss}</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#080B12] border border-[#1E293B]">
                <span className="text-[#8492A6]">Max Daily Trades:</span>
                <span className="font-bold text-white">{formData.maxDailyTrades} trades</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#080B12] border border-[#1E293B]">
                <span className="text-[#8492A6]">Risk Per Execution:</span>
                <span className="font-bold text-[#3987FF]">{formData.riskPerTradePercent}% of capital</span>
              </div>
            </div>

            {/* Confidence Slider */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1 font-mono">
                <span className="text-[#8492A6]">Confidence Rating:</span>
                <span className="font-bold text-[#00D6A0]">{formData.confidenceScore} / 10</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={formData.confidenceScore}
                onChange={(e) => setFormData({ ...formData, confidenceScore: Number(e.target.value) })}
                className="w-full accent-[#00D6A0] h-1.5 bg-[#182333] rounded-lg cursor-pointer"
              />
            </div>
          </div>

          {/* End-of-Day Journal Card */}
          <div className="trade-card rounded-2xl p-5 border border-[#1E293B] space-y-3">
            <div className="flex items-center justify-between pb-3 border-b border-[#1E293B]">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <BrainCircuit size={16} className="text-[#9875FF]" />
                3. End-of-Day Review
              </h3>
              <span className="text-xs font-mono font-bold text-white">
                {todayTrades.length} Trades Taken
              </span>
            </div>

            <div className="p-3 rounded-xl bg-[#080B12] border border-[#1E293B] flex items-center justify-between">
              <span className="text-xs text-[#8492A6]">Session Realized:</span>
              <span className={`text-base font-extrabold font-mono ${todayPnl >= 0 ? 'text-[#00D6A0]' : 'text-[#FF5268]'}`}>
                {todayPnl >= 0 ? '+' : ''}{formatCurrency(todayPnl)}
              </span>
            </div>

            <div className="text-xs text-[#8492A6] leading-relaxed">
              Every day's trading discipline is recorded into your journal analytics. Save your playbook each morning before market open.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
