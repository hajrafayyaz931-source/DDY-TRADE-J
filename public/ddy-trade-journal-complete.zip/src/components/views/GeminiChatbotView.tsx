import React, { useState, useRef, useEffect } from 'react';
import { Trade, ChallengeDay } from '../../types/trade';
import { 
  Bot, 
  Send, 
  Sparkles, 
  User, 
  Trash2, 
  RefreshCw, 
  Zap, 
  ShieldAlert, 
  HeartHandshake, 
  Trophy, 
  CheckCircle2,
  Copy,
  ChevronDown,
  RotateCcw
} from 'lucide-react';
import { formatCurrency } from '../../utils/calculations';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

interface GeminiChatbotViewProps {
  trades: Trade[];
  challengeDays: ChallengeDay[];
}

export function GeminiChatbotView({ trades, challengeDays }: GeminiChatbotViewProps) {
  // Default to gemini-3.1-flash-lite for ultra-fast, highly-available responses without 503 spikes
  const [model, setModel] = useState<'gemini-3.1-flash-lite' | 'gemini-3.8-flash' | 'gemini-4-argon'>('gemini-3.1-flash-lite');
  const [rolePreset, setRolePreset] = useState<'challenge' | 'general' | 'quotex' | 'psychology'>('challenge');
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [lastFailedText, setLastFailedText] = useState<string | null>(null);

  // Active Challenge status context
  const activeDay = challengeDays.find(d => d.status === 'in_progress') || challengeDays[4];
  const achievedDays = challengeDays.filter(d => d.status === 'achieved');
  const totalPnl = trades.reduce((acc, t) => acc + t.pnl, 0);

  // Initial greeting message
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-init',
      role: 'assistant',
      content: `Welcome to **DDY TRADE JOURNAL AI**! I am your visual trading mentor and quantitative performance coach powered by Google Gemini.

I have direct access to your **$100 to $5000 30-Day Challenge Target Journal** (currently on **Day ${activeDay.day}**, target: +$${activeDay.profitTarget}, lot size: ${activeDay.lotSize}) and your **${trades.length} recorded journal executions**.

How can I assist your trading session today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  // System instruction based on selected role
  const getSystemInstruction = () => {
    const baseContext = `You are TradePath Intelligence, powered by Gemini. You are analyzing a trader who has:
- ${trades.length} closed trades in their journal (Net PnL: $${totalPnl.toFixed(2)}).
- An active "$100 to $5000 30-Day Trading Challenge Target Journal". Currently on Day ${activeDay.day} with balance $${activeDay.startingBalance}, daily target +$${activeDay.profitTarget}, and recommended lot size ${activeDay.lotSize} (Quotex bet: $${activeDay.quotexInvestment}).
- ${achievedDays.length} days successfully achieved so far.`;

    switch (rolePreset) {
      case 'challenge':
        return `${baseContext}
Your role: 30-Day Compounding Challenge Coach.
Focus strictly on lot sizing, daily targets, and protecting the accumulated capital. Warn vigorously if the trader wants to jump ahead, trade excess size, or gamble beyond the daily profit target.`;
      case 'quotex':
        return `${baseContext}
Your role: Quotex Binary Options & OTC Strategist.
Advise on 1M and 5M expiration dynamics, support/resistance bounces, candlestick wicks, 85%+ payout selection, and why Martingale doubling is dangerous.`;
      case 'psychology':
        return `${baseContext}
Your role: Trading Psychology & Emotional Cooldown Guardian.
Detect signs of frustration, revenge trading, and FOMO. Provide cognitive reframing, calming advice, and enforce cooldown breaks after losses.`;
      default:
        return `${baseContext}
Your role: Senior Institutional Portfolio Mentor & Quantitative Analyst.
Provide balanced technical analysis, risk-to-reward optimization, and process discipline advice.`;
    }
  };

  const handleSendMessage = async (userText: string) => {
    if (!userText.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: userText.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInputMessage('');
    setLoading(true);
    setErrorMsg(null);
    setLastFailedText(null);

    try {
      // Prepare multi-turn messages payload
      const payloadMessages = newHistory.map(m => ({
        role: m.role,
        content: m.content,
      }));

      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: payloadMessages,
          systemInstruction: getSystemInstruction(),
          model,
        }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        let extracted = errorData.error || `HTTP ${res.status}: Failed to communicate with Gemini`;
        // Clean json parsing if error contains stringified JSON
        if (typeof extracted === 'string' && extracted.startsWith('{')) {
          try {
            const parsed = JSON.parse(extracted);
            extracted = parsed.error?.message || parsed.message || extracted;
          } catch {}
        }
        throw new Error(extracted);
      }

      const data = await res.json();
      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now()}-ai`,
        role: 'assistant',
        content: data.reply || 'No response generated.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error('Chatbot error:', err);
      let cleanMsg = err.message || 'Error contacting Gemini API. Please retry.';
      if (typeof cleanMsg === 'string' && cleanMsg.startsWith('{')) {
        try {
          const parsed = JSON.parse(cleanMsg);
          cleanMsg = parsed.error?.message || parsed.message || cleanMsg;
        } catch {}
      }
      setErrorMsg(cleanMsg);
      setLastFailedText(userText);
    } finally {
      setLoading(false);
    }
  };

  const handleRetry = () => {
    if (lastFailedText) {
      // Temporarily switch model to flash-lite if user was on something experiencing high demand
      if (model === 'gemini-3.8-flash') {
        setModel('gemini-3.1-flash-lite');
      }
      // Remove the last user message so it doesn't duplicate
      setMessages(prev => prev.slice(0, -1));
      handleSendMessage(lastFailedText);
    }
  };

  const handleClearHistory = () => {
    setMessages([
      {
        id: 'msg-reset',
        role: 'assistant',
        content: 'Conversation history cleared. How can I help you with your trading plan?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setErrorMsg(null);
    setLastFailedText(null);
  };

  const quickPrompts = [
    'How do I maintain discipline on Day 5 of the $100 to $5000 challenge?',
    'What should I do if I miss my daily target on Quotex?',
    'Explain why 2.2x Martingale is statistically dangerous for my challenge',
    'Review my journal trades and identify my highest probability setup',
  ];

  return (
    <div className="space-y-5">
      {/* Top Header Card */}
      <div className="p-5 rounded-2xl bg-[#07060A]/90 border border-[#8B5CF6]/25 backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.6)] flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#A78BFA]">
            <Bot size={15} className="text-[#C084FC]" />
            <span>GEMINI MULTI-TURN AI CHATBOT</span>
            <span className="text-[#A78BFA]/50">•</span>
            <span className="text-[#10B981] font-bold">Online & Grounded</span>
          </div>
          <h1 className="text-xl lg:text-2xl font-black text-white mt-1 tracking-tight">
            DDY TRADE JOURNAL AI Mentor
          </h1>
          <p className="text-xs text-[#CBD5E1] mt-0.5">
            Real-time conversational coaching for the $100 to $5000 challenge, Quotex binary setups, and risk discipline
          </p>
        </div>

        {/* Configuration Controls */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Role selector */}
          <div className="flex items-center bg-[#0D0B14] p-1 rounded-xl border border-[#8B5CF6]/25 text-xs">
            <button
              onClick={() => setRolePreset('challenge')}
              className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
                rolePreset === 'challenge' ? 'bg-[#F59E0B] text-[#07060A] shadow-[0_0_10px_rgba(245,158,11,0.4)]' : 'text-[#A78BFA] hover:text-white'
              }`}
            >
              <Trophy size={13} /> $100-$5000 Coach
            </button>
            <button
              onClick={() => setRolePreset('quotex')}
              className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
                rolePreset === 'quotex' ? 'bg-[#8B5CF6] text-white shadow-[0_0_10px_rgba(139,92,246,0.4)]' : 'text-[#A78BFA] hover:text-white'
              }`}
            >
              <Zap size={13} /> Quotex OTC
            </button>
            <button
              onClick={() => setRolePreset('psychology')}
              className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
                rolePreset === 'psychology' ? 'bg-[#10B981] text-[#07060A] shadow-[0_0_10px_rgba(16,185,129,0.4)]' : 'text-[#A78BFA] hover:text-white'
              }`}
            >
              <HeartHandshake size={13} /> Anti-FOMO
            </button>
          </div>

          {/* Model selector */}
          <select
            value={model}
            onChange={(e) => setModel(e.target.value as any)}
            className="bg-[#0D0B14] border border-[#8B5CF6]/30 rounded-xl px-3 py-2 text-xs font-mono text-[#C084FC] font-bold outline-none cursor-pointer"
          >
            <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Fast & Reliable)</option>
            <option value="gemini-3.8-flash">gemini-3.8-flash (General)</option>
            <option value="gemini-4-argon">gemini-4-argon (Complex)</option>
          </select>

          <button
            onClick={handleClearHistory}
            className="p-2 rounded-xl bg-[#0D0B14] hover:bg-[#1C1536] text-[#A78BFA] hover:text-[#EF4444] border border-[#8B5CF6]/25 transition-colors"
            title="Reset Chat History"
          >
            <Trash2 size={15} />
          </button>
        </div>
      </div>

      {/* Main Chat Container */}
      <div className="trade-card rounded-2xl border border-[#8B5CF6]/25 bg-[#07060A]/80 backdrop-blur-2xl shadow-2xl flex flex-col h-[650px] overflow-hidden">
        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';

            return (
              <div
                key={msg.id}
                className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : ''}`}
              >
                {/* Avatar */}
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                  isUser
                    ? 'bg-[#8B5CF6] text-white shadow-[0_0_12px_rgba(139,92,246,0.5)]'
                    : 'bg-[#0D0B14] text-[#C084FC] border border-[#8B5CF6]/40 shadow-[0_0_10px_rgba(192,132,252,0.3)]'
                }`}>
                  {isUser ? <User size={15} /> : <Bot size={16} />}
                </div>

                {/* Message Bubble */}
                <div className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 text-xs leading-relaxed ${
                  isUser
                    ? 'bg-gradient-to-tr from-[#7C3AED] to-[#8B5CF6] text-white rounded-tr-sm shadow-lg'
                    : 'bg-[#0D0B14]/90 text-slate-100 border border-[#8B5CF6]/25 rounded-tl-sm space-y-2 shadow-md'
                }`}>
                  <div className="whitespace-pre-wrap font-sans">
                    {msg.content}
                  </div>
                  <div className={`text-[10px] font-mono mt-1 ${isUser ? 'text-purple-200 text-right' : 'text-[#A78BFA]/70'}`}>
                    {msg.timestamp}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Loading indicator */}
          {loading && (
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-[#0D0B14] text-[#C084FC] border border-[#8B5CF6]/40 flex items-center justify-center shrink-0 animate-pulse">
                <Bot size={16} />
              </div>
              <div className="bg-[#0D0B14] border border-[#8B5CF6]/25 rounded-2xl p-3.5 text-xs text-[#A78BFA] flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#C084FC] animate-ping"></span>
                <span className="font-mono">TradePath Intelligence is reasoning with Gemini...</span>
              </div>
            </div>
          )}

          {/* Error Banner with Retry button */}
          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/35 text-rose-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-in fade-in duration-200 shadow-[0_0_16px_rgba(239,68,68,0.2)]">
              <div className="flex items-center gap-2.5">
                <ShieldAlert size={16} className="text-[#EF4444] shrink-0" />
                <span className="font-sans leading-snug">{errorMsg}</span>
              </div>
              {lastFailedText && (
                <button
                  onClick={handleRetry}
                  className="px-3 py-1.5 rounded-lg bg-[#EF4444]/25 hover:bg-[#EF4444]/35 border border-[#EF4444]/50 text-white font-bold flex items-center gap-1.5 shrink-0 transition-all active:scale-95 text-xs font-mono"
                >
                  <RotateCcw size={13} />
                  <span>Retry Now</span>
                </button>
              )}
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 border-t border-[#8B5CF6]/15 bg-[#0D0B14]/80 overflow-x-auto flex items-center gap-2">
          <span className="text-[10px] text-[#A78BFA] uppercase tracking-wider font-mono font-bold shrink-0">
            Suggested:
          </span>
          {quickPrompts.map((qp, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(qp)}
              disabled={loading}
              className="px-2.5 py-1 rounded-lg bg-[#07060A] hover:bg-[#1C1536] border border-[#8B5CF6]/25 text-[11px] text-slate-300 hover:text-white whitespace-nowrap transition-all hover:border-[#8B5CF6]/60"
            >
              {qp}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-[#8B5CF6]/20 bg-[#0A0713]">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage(inputMessage);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Ask TradePath AI about your $100–$5000 challenge, Quotex setups, psychology, or position sizing..."
              disabled={loading}
              className="flex-1 bg-[#07060A] border border-[#8B5CF6]/30 rounded-xl px-4 py-3 text-xs text-white placeholder-[#94A3B8] outline-none focus:border-[#C084FC] transition-colors"
            />
            <button
              type="submit"
              disabled={loading || !inputMessage.trim()}
              className={`px-5 py-3 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                loading || !inputMessage.trim()
                  ? 'bg-[#1C1536] text-[#A78BFA]/50 cursor-not-allowed'
                  : 'btn-premium-purple text-white shadow-[0_0_16px_rgba(139,92,246,0.4)]'
              }`}
            >
              <Send size={14} />
              <span className="hidden sm:inline">Send</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
