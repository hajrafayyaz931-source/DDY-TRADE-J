import React, { useState, useMemo } from 'react';
import { Trade, TradeEmotion, TradingSession } from '../../types/trade';
import { 
  Table, 
  LayoutGrid, 
  Clock, 
  Search, 
  Filter, 
  Download, 
  Plus, 
  ArrowUpRight, 
  ArrowDownRight, 
  CheckCircle2, 
  AlertCircle, 
  Calendar, 
  Sparkles,
  TrendingUp,
  TrendingDown,
  Trash2,
  Eye,
  FileSpreadsheet,
  Tag,
  MessageSquare,
  PlayCircle,
  X
} from 'lucide-react';
import { formatCurrency, generateCsvExport } from '../../utils/calculations';
import { EmptyState } from '../ui/SkeletonAndEmptyStates';

interface TradeJournalViewProps {
  trades: Trade[];
  onSelectTrade: (trade: Trade) => void;
  onOpenLogTrade: () => void;
  onOpenAutoImport: () => void;
  onDeleteTrade: (id: string) => void;
  selectedDateFilter: string | null;
  onClearDateFilter: () => void;
}

const COMMON_TAGS = [
  'All',
  'Breakout',
  'Reversal',
  'Trend Following',
  'News',
  'Scalp',
  'Liquidity Sweep',
  'Key Level',
];

export function TradeJournalView({
  trades,
  onSelectTrade,
  onOpenLogTrade,
  onOpenAutoImport,
  onDeleteTrade,
  selectedDateFilter,
  onClearDateFilter,
}: TradeJournalViewProps) {
  const [viewMode, setViewMode] = useState<'table' | 'gallery' | 'timeline'>('table');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'binary' | 'cfd'>('all');
  const [filterDirection, setFilterDirection] = useState<'all' | 'long' | 'short'>('all');
  const [filterOutcome, setFilterOutcome] = useState<'all' | 'win' | 'loss' | 'be'>('all');
  const [filterEmotion, setFilterEmotion] = useState<string>('all');
  const [filterSession, setFilterSession] = useState<string>('all');
  const [selectedTag, setSelectedTag] = useState<string>('All');
  const [selectedSymbol, setSelectedSymbol] = useState<string>('all');

  // Quick notes popover state
  const [activeNotesTrade, setActiveNotesTrade] = useState<Trade | null>(null);

  // Available unique symbols
  const uniqueSymbols = useMemo(() => {
    return Array.from(new Set(trades.map(t => t.symbol))).sort();
  }, [trades]);

  // Filter trades
  const filteredTrades = useMemo(() => {
    return trades.filter(t => {
      if (selectedDateFilter && t.date !== selectedDateFilter) return false;
      if (filterType !== 'all' && t.type !== filterType) return false;
      
      if (filterDirection === 'long') {
        if (t.direction !== 'Long' && t.direction !== 'CALL') return false;
      } else if (filterDirection === 'short') {
        if (t.direction !== 'Short' && t.direction !== 'PUT') return false;
      }

      if (filterOutcome === 'win' && t.pnl <= 0) return false;
      if (filterOutcome === 'loss' && t.pnl >= 0) return false;
      if (filterOutcome === 'be' && t.pnl !== 0) return false;

      if (filterEmotion !== 'all' && t.emotion !== filterEmotion) return false;
      if (filterSession !== 'all' && t.session !== filterSession) return false;
      if (selectedSymbol !== 'all' && t.symbol !== selectedSymbol) return false;

      // Tag filter
      if (selectedTag !== 'All') {
        const tags = t.tags || [t.strategy];
        const hasTag = tags.some(tag => tag.toLowerCase().includes(selectedTag.toLowerCase()));
        if (!hasTag) return false;
      }

      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const match = 
          t.symbol.toLowerCase().includes(q) ||
          t.strategy.toLowerCase().includes(q) ||
          (t.ticket && t.ticket.toLowerCase().includes(q)) ||
          (t.notes && t.notes.toLowerCase().includes(q)) ||
          (t.tags && t.tags.some(tag => tag.toLowerCase().includes(q)));
        if (!match) return false;
      }

      return true;
    });
  }, [
    trades, 
    selectedDateFilter, 
    filterType, 
    filterDirection, 
    filterOutcome, 
    filterEmotion, 
    filterSession, 
    selectedSymbol, 
    selectedTag, 
    searchQuery
  ]);

  // Export to CSV
  const handleExportCsv = () => {
    const csvContent = generateCsvExport(filteredTrades);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `DDY_Trade_Journal_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const totalFilteredPnl = filteredTrades.reduce((acc, t) => acc + t.pnl, 0);
  const winCount = filteredTrades.filter(t => t.pnl > 0).length;
  const filteredWinRate = filteredTrades.length > 0 ? (winCount / filteredTrades.length) * 100 : 0;

  return (
    <div className="space-y-5">
      {/* Top Header & View Mode Switcher */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-5 rounded-2xl trade-card border border-[#8B5CF6]/25 shadow-2xl backdrop-blur-2xl">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-xl lg:text-2xl font-black text-white tracking-tight">
              Trade Execution Journal
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 text-[#C084FC] font-mono font-bold shadow-[0_0_8px_rgba(139,92,246,0.3)]">
              {filteredTrades.length} Records
            </span>
          </div>
          <p className="text-xs text-[#A78BFA]/80 mt-1">
            Plan, document, review, and analyze every single execution with high-visual verification
          </p>
        </div>

        {/* View Mode Buttons & Actions */}
        <div className="flex flex-wrap items-center gap-2">
          {/* View mode toggle */}
          <div className="flex items-center bg-[#07060A]/80 p-1 rounded-2xl border border-[#8B5CF6]/25 text-xs font-sans">
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all ${
                viewMode === 'table' ? 'bg-[#8B5CF6] text-white shadow-[0_0_12px_rgba(139,92,246,0.5)]' : 'text-[#A78BFA] hover:text-white'
              }`}
            >
              <Table size={14} /> Table View
            </button>
            <button
              onClick={() => setViewMode('gallery')}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all ${
                viewMode === 'gallery' ? 'bg-[#8B5CF6] text-white shadow-[0_0_12px_rgba(139,92,246,0.5)]' : 'text-[#A78BFA] hover:text-white'
              }`}
            >
              <LayoutGrid size={14} /> Visual Gallery
            </button>
            <button
              onClick={() => setViewMode('timeline')}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all ${
                viewMode === 'timeline' ? 'bg-[#8B5CF6] text-white shadow-[0_0_12px_rgba(139,92,246,0.5)]' : 'text-[#A78BFA] hover:text-white'
              }`}
            >
              <Clock size={14} /> Timeline
            </button>
          </div>

          <button
            onClick={handleExportCsv}
            className="px-3.5 py-1.5 rounded-2xl btn-glass-subtle text-xs font-semibold flex items-center gap-1.5"
            title="Export filtered records to CSV"
          >
            <Download size={14} className="text-[#10B981]" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={onOpenLogTrade}
            className="px-4 py-1.5 rounded-2xl btn-premium-purple text-xs font-bold flex items-center gap-1.5"
          >
            <Plus size={15} />
            <span>Log Trade</span>
          </button>
        </div>
      </div>

      {/* Smart Search & Filter Hub */}
      <div className="p-4 rounded-2xl bg-[#07060A]/90 border border-[#8B5CF6]/25 shadow-xl backdrop-blur-2xl space-y-3.5">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Smart Search Box */}
          <div className="flex-1 relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#A78BFA]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Symbol (BTCUSDT, EUR/USD OTC), Setup, Ticket #, Notes, or Tag..."
              className="w-full bg-[#0D0B14] border border-[#8B5CF6]/25 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-[#8B5CF6]/50 outline-none focus:border-[#8B5CF6] shadow-[inset_0_1px_1px_rgba(255,255,255,0.05)]"
            />
          </div>

          {/* Quick Select Filters */}
          <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
            {/* Symbol Filter */}
            <select
              value={selectedSymbol}
              onChange={(e) => setSelectedSymbol(e.target.value)}
              className="bg-[#0D0B14] border border-[#8B5CF6]/25 rounded-xl px-2.5 py-2 text-white outline-none cursor-pointer"
            >
              <option value="all">All Pairs</option>
              {uniqueSymbols.map(sym => (
                <option key={sym} value={sym}>{sym}</option>
              ))}
            </select>

            {/* Instrument Type */}
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as any)}
              className="bg-[#0D0B14] border border-[#8B5CF6]/25 rounded-xl px-2.5 py-2 text-white outline-none cursor-pointer"
            >
              <option value="all">All Instruments</option>
              <option value="binary">Quotex Binary (OTC)</option>
              <option value="cfd">Forex / Futures / Crypto</option>
            </select>

            {/* Outcome */}
            <select
              value={filterOutcome}
              onChange={(e) => setFilterOutcome(e.target.value as any)}
              className="bg-[#0D0B14] border border-[#8B5CF6]/25 rounded-xl px-2.5 py-2 text-white outline-none cursor-pointer"
            >
              <option value="all">All Outcomes</option>
              <option value="win">Wins (ITM / Profit)</option>
              <option value="loss">Losses (OTM / Drawdown)</option>
              <option value="be">Breakeven / Tie</option>
            </select>

            {/* Session */}
            <select
              value={filterSession}
              onChange={(e) => setFilterSession(e.target.value)}
              className="bg-[#0D0B14] border border-[#8B5CF6]/25 rounded-xl px-2.5 py-2 text-white outline-none cursor-pointer"
            >
              <option value="all">All Sessions</option>
              <option value="New York Open">New York Open</option>
              <option value="London">London</option>
              <option value="Asian / Tokyo">Asian / Tokyo</option>
              <option value="OTC Weekend">OTC Weekend</option>
              <option value="24/7 Crypto">24/7 Crypto</option>
            </select>
          </div>
        </div>

        {/* Tag Filter Chips */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          <span className="text-[11px] text-[#A78BFA] font-mono mr-1.5 flex items-center gap-1">
            <Tag size={12} className="text-[#8B5CF6]" /> Tags:
          </span>
          {COMMON_TAGS.map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold transition-all ${
                selectedTag === tag
                  ? 'bg-[#8B5CF6] text-white shadow-[0_0_10px_rgba(139,92,246,0.4)]'
                  : 'bg-[#0D0B14] text-[#A78BFA] border border-[#8B5CF6]/20 hover:border-[#8B5CF6]/40 hover:text-white'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>

        {/* Filter Summary Banner */}
        <div className="flex flex-wrap items-center justify-between text-xs text-[#A78BFA] pt-2 border-t border-[#8B5CF6]/20 font-mono">
          <div className="flex items-center gap-3">
            <span>Filtered PnL: <strong className={totalFilteredPnl >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}>
              {totalFilteredPnl >= 0 ? '+' : ''}{formatCurrency(totalFilteredPnl)}
            </strong></span>
            <span>Win Rate: <strong className="text-white">{filteredWinRate.toFixed(1)}%</strong></span>
            {selectedDateFilter && (
              <span className="px-2 py-0.5 rounded bg-[#8B5CF6]/20 text-[#C084FC] border border-[#8B5CF6]/30 flex items-center gap-1">
                Date: {selectedDateFilter}
                <button onClick={onClearDateFilter} className="hover:text-white ml-1">×</button>
              </span>
            )}
          </div>

          {(searchQuery || filterType !== 'all' || filterDirection !== 'all' || filterOutcome !== 'all' || filterSession !== 'all' || selectedSymbol !== 'all' || selectedTag !== 'All') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setFilterType('all');
                setFilterDirection('all');
                setFilterOutcome('all');
                setFilterSession('all');
                setSelectedSymbol('all');
                setSelectedTag('All');
              }}
              className="text-[#C084FC] hover:underline cursor-pointer"
            >
              Reset All Filters
            </button>
          )}
        </div>
      </div>

      {/* Quick Trade Replay Notes Drawer Modal if open */}
      {activeNotesTrade && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg bg-[#07060A]/95 border border-[#8B5CF6]/30 rounded-2xl shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#8B5CF6]/20 pb-3">
              <div className="flex items-center gap-2">
                <PlayCircle size={18} className="text-[#8B5CF6]" />
                <h3 className="font-bold text-white text-sm">
                  Trade Replay & Notes — {activeNotesTrade.symbol} ({activeNotesTrade.ticket})
                </h3>
              </div>
              <button
                onClick={() => setActiveNotesTrade(null)}
                className="text-[#A78BFA] hover:text-white"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-3 text-xs font-mono">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#0D0B14] border border-[#8B5CF6]/20">
                <span className="text-[#A78BFA]">Execution Result:</span>
                <span className={`font-bold ${activeNotesTrade.pnl >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                  {activeNotesTrade.pnl >= 0 ? '+' : ''}{formatCurrency(activeNotesTrade.pnl)} ({activeNotesTrade.direction})
                </span>
              </div>

              <div>
                <span className="text-[#A78BFA] block mb-1">Entry Thesis / Setup:</span>
                <p className="p-3 rounded-xl bg-[#0D0B14] border border-[#8B5CF6]/20 text-slate-200 leading-relaxed">
                  {activeNotesTrade.entryReason || `Executed ${activeNotesTrade.strategy} in ${activeNotesTrade.session}.`}
                </p>
              </div>

              <div>
                <span className="text-[#A78BFA] block mb-1">Reflection & Post-Mortem Notes:</span>
                <p className="p-3 rounded-xl bg-[#0D0B14] border border-[#8B5CF6]/20 text-slate-200 leading-relaxed whitespace-pre-wrap">
                  {activeNotesTrade.notes || 'No reflections recorded.'}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-[#8B5CF6]/20">
              <button
                onClick={() => {
                  onSelectTrade(activeNotesTrade);
                  setActiveNotesTrade(null);
                }}
                className="btn-premium-purple px-4 py-2 rounded-xl text-xs font-bold text-white"
              >
                Open Full Candlestick Inspector
              </button>
              <button
                onClick={() => setActiveNotesTrade(null)}
                className="btn-glass-subtle px-4 py-2 rounded-xl text-xs font-bold text-white"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RENDER VIEWS OR EMPTY STATE */}
      {filteredTrades.length === 0 ? (
        <EmptyState
          icon={Search}
          title={trades.length === 0 ? "No Trades Recorded Yet" : "No Matching Trades Found"}
          description={
            trades.length === 0
              ? "Your institutional trading journal is empty. Log your first Quotex OTC or CFD trade to activate your journal blotter, edge analytics, and equity curve."
              : "No trade records match your active search and filter criteria. Clear filters or adjust your criteria to view records."
          }
          actionText="Log New Trade"
          onAction={onOpenLogTrade}
          secondaryActionText={trades.length > 0 ? "Reset All Filters" : "Auto-Import Trades"}
          onSecondaryAction={() => {
            if (trades.length > 0) {
              setSearchQuery('');
              setFilterType('all');
              setFilterDirection('all');
              setFilterOutcome('all');
              setFilterEmotion('all');
              setFilterSession('all');
              setSelectedTag('All');
              setSelectedSymbol('all');
              onClearDateFilter();
            } else {
              onOpenAutoImport();
            }
          }}
        />
      ) : (
        <>
          {/* VIEW 1: DETAILED TABLE VIEW */}
          {viewMode === 'table' && (
            <div className="trade-card rounded-2xl overflow-hidden border border-[#8B5CF6]/25 shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#07060A] text-[#A78BFA] text-[10px] font-mono uppercase border-b border-[#8B5CF6]/20">
                <tr>
                  <th className="py-3 px-4">Instrument / ID</th>
                  <th className="py-3 px-3">Type</th>
                  <th className="py-3 px-3">Direction</th>
                  <th className="py-3 px-4">Entry → Settlement</th>
                  <th className="py-3 px-3 text-right">Size / Risk</th>
                  <th className="py-3 px-3 text-right">R-Multiple</th>
                  <th className="py-3 px-4 text-right">Net PnL</th>
                  <th className="py-3 px-3">Setup / Tags</th>
                  <th className="py-3 px-3">Emotion</th>
                  <th className="py-3 px-3 text-center">Rules</th>
                  <th className="py-3 px-4 text-right">Date</th>
                  <th className="py-3 px-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#8B5CF6]/15">
                {filteredTrades.map((t) => {
                  const isUp = t.direction === 'CALL' || t.direction === 'Long';
                  const isWin = t.pnl > 0;
                  const isLoss = t.pnl < 0;
                  const tradeTags = t.tags || [t.strategy];

                  return (
                    <tr
                      key={t.id}
                      onClick={() => onSelectTrade(t)}
                      className="hover:bg-[#8B5CF6]/10 cursor-pointer transition-all group"
                    >
                      <td className="py-3.5 px-4 font-bold text-white">
                        <div className="flex items-center gap-2">
                          <span>{t.symbol}</span>
                          {t.screenshotUrl && (
                            <span title="Screenshot attached" className="w-2 h-2 rounded-full bg-[#8B5CF6] shadow-[0_0_6px_#8B5CF6]"></span>
                          )}
                        </div>
                        <span className="text-[10px] text-[#A78BFA]/70 font-mono block mt-0.5">
                          {t.ticket}
                        </span>
                      </td>

                      <td className="py-3.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                          t.type === 'binary' ? 'bg-[#8B5CF6]/20 text-[#C084FC] border border-[#8B5CF6]/30' : 'bg-[#3B82F6]/20 text-[#60A5FA] border border-[#3B82F6]/30'
                        }`}>
                          {t.type === 'binary' ? 'Quotex OTC' : 'CFD'}
                        </span>
                      </td>

                      <td className="py-3.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono inline-flex items-center gap-1 ${
                          isUp 
                            ? 'bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30 shadow-[0_0_8px_rgba(16,185,129,0.2)]' 
                            : 'bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30 shadow-[0_0_8px_rgba(239,68,68,0.2)]'
                        }`}>
                          {isUp ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                          {t.direction}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 font-mono text-[#A78BFA]/80">
                        <span className="text-white">{t.entry.toLocaleString()}</span> → <span>{t.exit.toLocaleString()}</span>
                      </td>

                      <td className="py-3.5 px-3 text-right font-mono text-slate-300">
                        {t.type === 'binary' ? formatCurrency(t.investment || 50) : `${t.size || 1} units`}
                      </td>

                      <td className={`py-3.5 px-3 text-right font-mono font-bold ${
                        t.rMultiple !== undefined && t.rMultiple >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
                      }`}>
                        {t.rMultiple !== undefined ? `${t.rMultiple > 0 ? '+' : ''}${t.rMultiple.toFixed(2)}R` : 'N/A'}
                      </td>

                      <td className={`py-3.5 px-4 text-right font-mono font-bold text-sm ${
                        isWin ? 'text-[#10B981]' : isLoss ? 'text-[#EF4444]' : 'text-slate-300'
                      }`}>
                        {isWin ? '+' : ''}{formatCurrency(t.pnl)}
                      </td>

                      <td className="py-3.5 px-3">
                        <div className="flex flex-wrap items-center gap-1 max-w-[150px]">
                          {tradeTags.slice(0, 2).map((tg, i) => (
                            <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-[#1A132B] text-[#C084FC] border border-[#8B5CF6]/30 font-mono truncate">
                              {tg}
                            </span>
                          ))}
                        </div>
                      </td>

                      <td className="py-3.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold ${
                          t.emotion === 'Calm' || t.emotion === 'Disciplined' || t.emotion === 'Confident'
                            ? 'text-[#10B981] bg-[#10B981]/15 border border-[#10B981]/25'
                            : 'text-[#EF4444] bg-[#EF4444]/15 border border-[#EF4444]/25'
                        }`}>
                          {t.emotion}
                        </span>
                      </td>

                      <td className="py-3.5 px-3 text-center font-mono">
                        <span className="text-slate-300">
                          {t.rulesFollowed}/{t.totalRules || 5}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono text-[#A78BFA] text-[11px]">
                        {t.date}
                      </td>

                      <td className="py-3.5 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => setActiveNotesTrade(t)}
                            className="p-1 rounded text-[#A78BFA] hover:text-[#C084FC] hover:bg-[#8B5CF6]/20 transition-all"
                            title="Quick replay notes"
                          >
                            <MessageSquare size={13} />
                          </button>
                          <button
                            onClick={() => onSelectTrade(t)}
                            className="p-1 rounded text-[#A78BFA] hover:text-white hover:bg-[#8B5CF6]/20 transition-all"
                            title="Inspect details & replay"
                          >
                            <Eye size={13} />
                          </button>
                          <button
                            onClick={() => onDeleteTrade(t.id)}
                            className="p-1 rounded text-[#EF4444] hover:text-rose-400 hover:bg-rose-500/15 transition-all"
                            title="Delete trade"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VIEW 2: VISUAL TRADE GALLERY */}
      {viewMode === 'gallery' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTrades.map((t) => {
            const isUp = t.direction === 'CALL' || t.direction === 'Long';
            const isWin = t.pnl > 0;
            const isLoss = t.pnl < 0;
            const tradeTags = t.tags || [t.strategy];

            return (
              <div
                key={t.id}
                onClick={() => onSelectTrade(t)}
                className="trade-card rounded-2xl p-5 border border-[#8B5CF6]/25 cursor-pointer transition-all hover:-translate-y-1 hover:border-[#8B5CF6]/60 flex flex-col justify-between shadow-lg"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className={`p-1.5 rounded-lg text-xs font-bold ${
                        isUp ? 'bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30' : 'bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30'
                      }`}>
                        {isUp ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                      </span>
                      <div>
                        <h3 className="font-extrabold text-sm text-white">{t.symbol}</h3>
                        <span className="text-[10px] text-[#A78BFA] font-mono">{t.date} • {t.session}</span>
                      </div>
                    </div>

                    <span className={`px-2.5 py-1 rounded-full text-xs font-bold font-mono ${
                      isWin 
                        ? 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/35 shadow-[0_0_8px_rgba(16,185,129,0.3)]' 
                        : isLoss 
                        ? 'bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/35 shadow-[0_0_8px_rgba(239,68,68,0.3)]' 
                        : 'bg-slate-700/50 text-slate-300'
                    }`}>
                      {isWin ? '+' : ''}{formatCurrency(t.pnl)}
                    </span>
                  </div>

                  {/* Setup & Notes */}
                  <div className="p-3 rounded-xl bg-[#0D0B14]/80 border border-[#8B5CF6]/20 space-y-1.5 mb-3">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-[#A78BFA]">Strategy:</span>
                      <span className="font-semibold text-slate-200">{t.strategy}</span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] font-mono">
                      <span className="text-[#A78BFA]">Entry → Exit:</span>
                      <span className="text-slate-300">{t.entry} → {t.exit}</span>
                    </div>
                    {t.rMultiple !== undefined && (
                      <div className="flex items-center justify-between text-[11px] font-mono">
                        <span className="text-[#A78BFA]">R-Multiple:</span>
                        <span className={t.rMultiple >= 0 ? 'text-[#10B981] font-bold' : 'text-[#EF4444] font-bold'}>
                          {t.rMultiple > 0 ? '+' : ''}{t.rMultiple.toFixed(2)}R
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap items-center gap-1 mb-2">
                    {tradeTags.map((tg, i) => (
                      <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-[#1C1433] text-[#C084FC] border border-[#8B5CF6]/25 font-mono">
                        #{tg}
                      </span>
                    ))}
                  </div>

                  {/* Reflection quote */}
                  <p className="text-[11px] text-[#A78BFA]/80 line-clamp-2 italic">
                    "{t.notes || t.entryReason || 'No notes attached.'}"
                  </p>
                </div>

                {/* Footer tags */}
                <div className="flex items-center justify-between pt-3 mt-3 border-t border-[#8B5CF6]/20 text-[10px] font-mono">
                  <span className="text-[#A78BFA]">Emotion: <strong className="text-white">{t.emotion}</strong></span>
                  <span className="text-[#10B981] font-bold">{t.rulesFollowed}/{t.totalRules || 5} Rules</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* VIEW 3: CHRONOLOGICAL TRADE TIMELINE */}
      {viewMode === 'timeline' && (
        <div className="trade-card rounded-2xl p-6 border border-[#8B5CF6]/25">
          <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-[#8B5CF6]/25">
            {filteredTrades.map((t) => {
              const isUp = t.direction === 'CALL' || t.direction === 'Long';
              const isWin = t.pnl > 0;

              return (
                <div key={t.id} className="relative group cursor-pointer" onClick={() => onSelectTrade(t)}>
                  {/* Timeline node */}
                  <div className={`absolute -left-[27px] top-1.5 w-3.5 h-3.5 rounded-full border-2 border-[#07060A] ${
                    isWin ? 'bg-[#10B981] shadow-[0_0_8px_#10B981]' : 'bg-[#EF4444] shadow-[0_0_8px_#EF4444]'
                  }`} />

                  <div className="p-4 rounded-xl bg-[#0D0B14]/80 border border-[#8B5CF6]/20 group-hover:border-[#8B5CF6]/50 transition-all">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-sm text-white">{t.symbol}</span>
                        <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold font-mono ${
                          isUp ? 'text-[#10B981]' : 'text-[#EF4444]'
                        }`}>
                          {t.direction}
                        </span>
                        <span className="text-[10px] text-[#A78BFA] font-mono">{t.date} {t.time ? `• ${t.time}` : ''}</span>
                      </div>

                      <span className={`text-sm font-black font-mono ${isWin ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                        {isWin ? '+' : ''}{formatCurrency(t.pnl)}
                      </span>
                    </div>

                    <p className="text-xs text-slate-300">
                      {t.entryReason || t.notes || `${t.strategy} trade execution during ${t.session} session.`}
                    </p>

                    <div className="flex items-center gap-4 mt-2 text-[10px] text-[#A78BFA] font-mono">
                      <span>Setup: <strong className="text-slate-300">{t.strategy}</strong></span>
                      <span>Rules: <strong className="text-[#10B981]">{t.rulesFollowed}/{t.totalRules || 5}</strong></span>
                      <span>Emotion: <strong className="text-slate-300">{t.emotion}</strong></span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
        </>
      )}
    </div>
  );
}
