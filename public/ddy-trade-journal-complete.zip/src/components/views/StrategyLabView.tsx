import React, { useState } from 'react';
import { StrategyItem, Trade } from '../../types/trade';
import { Layers, Plus, TrendingUp, Target, BarChart2, CheckCircle2 } from 'lucide-react';
import { formatCurrency } from '../../utils/calculations';

interface StrategyLabViewProps {
  strategies: StrategyItem[];
  trades: Trade[];
  onAddStrategy: (item: StrategyItem) => void;
}

export function StrategyLabView({ strategies, trades, onAddStrategy }: StrategyLabViewProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [entryCrit, setEntryCrit] = useState('');
  const [exitCrit, setExitCrit] = useState('');

  // Performance per strategy
  const stratPerformance: Record<string, { count: number; wins: number; pnl: number; rMultiples: number[] }> = {};
  trades.forEach(t => {
    const s = t.strategy || 'Unspecified';
    if (!stratPerformance[s]) {
      stratPerformance[s] = { count: 0, wins: 0, pnl: 0, rMultiples: [] };
    }
    stratPerformance[s].count++;
    stratPerformance[s].pnl += t.pnl;
    if (t.pnl > 0) stratPerformance[s].wins++;
    if (t.rMultiple !== undefined) stratPerformance[s].rMultiples.push(t.rMultiple);
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onAddStrategy({
      id: `strat-${Date.now()}`,
      name,
      description: desc,
      marketConditions: ['Strong Trend', 'Breakout'],
      entryCriteria: entryCrit,
      exitCriteria: exitCrit,
      timeframes: ['5m', '15m'],
      recommendedR: '2.0R',
      tags: ['Custom'],
    });
    setName('');
    setDesc('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-[#101722] border border-[#1E293B]">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#8492A6]">
            <Layers size={14} className="text-[#3987FF]" />
            <span>STRATEGY RESEARCH & SETUP LAB</span>
          </div>
          <h1 className="text-xl lg:text-2xl font-extrabold text-white mt-1 tracking-tight">
            Strategy Playbook & Mathematical Edge
          </h1>
          <p className="text-xs text-[#8492A6] mt-0.5">
            Evaluate, test, and document setup criteria with verified performance statistics
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 rounded-xl bg-[#3987FF] hover:bg-[#2F74DE] text-white text-xs font-bold flex items-center gap-2 shadow-[0_0_15px_rgba(57,135,255,0.4)]"
        >
          <Plus size={15} />
          <span>New Strategy Setup</span>
        </button>
      </div>

      {/* Strategies List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {strategies.map((strat) => {
          const perf = stratPerformance[strat.name] || { count: 0, wins: 0, pnl: 0, rMultiples: [] };
          const winRate = perf.count > 0 ? Math.round((perf.wins / perf.count) * 100) : 0;
          const avgR = perf.rMultiples.length > 0 ? (perf.rMultiples.reduce((a, b) => a + b, 0) / perf.rMultiples.length).toFixed(2) : '1.80';
          const isPos = perf.pnl >= 0;

          return (
            <div key={strat.id} className="trade-card rounded-2xl p-6 border border-[#1E293B] space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <h3 className="text-base font-extrabold text-white">{strat.name}</h3>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {strat.tags.map(tag => (
                        <span key={tag} className="text-[10px] px-2 py-0.5 rounded bg-[#182333] border border-[#26354A] text-slate-300 font-mono">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  <span className={`px-2.5 py-1 rounded-full text-xs font-mono font-bold ${
                    isPos ? 'bg-[#00D6A0]/15 text-[#00D6A0] border border-[#00D6A0]/30' : 'bg-[#FF5268]/15 text-[#FF5268] border border-[#FF5268]/30'
                  }`}>
                    {isPos ? '+' : ''}{formatCurrency(perf.pnl)}
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  {strat.description}
                </p>

                {/* Performance pill stats */}
                <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-[#080B12] border border-[#1E293B] text-center font-mono text-xs">
                  <div>
                    <span className="text-[10px] text-[#8492A6] block">Win Rate</span>
                    <span className="font-bold text-[#00D6A0]">{winRate}%</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#8492A6] block">Trades Logged</span>
                    <span className="font-bold text-white">{perf.count}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#8492A6] block">Average R</span>
                    <span className="font-bold text-[#3987FF]">{avgR}R</span>
                  </div>
                </div>

                {/* Entry & Exit Criteria */}
                <div className="space-y-2 mt-4 text-xs">
                  <div>
                    <span className="text-[#8492A6] block text-[10px] uppercase font-bold tracking-wider font-mono">
                      Entry Rules
                    </span>
                    <span className="text-slate-200">{strat.entryCriteria}</span>
                  </div>
                  <div>
                    <span className="text-[#8492A6] block text-[10px] uppercase font-bold tracking-wider font-mono">
                      Exit Target
                    </span>
                    <span className="text-slate-200">{strat.exitCriteria}</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-[#1E293B] text-[11px] text-[#8492A6] font-mono flex items-center justify-between">
                <span>Recommended: {strat.recommendedR}</span>
                <span className="text-[#00D6A0] font-bold">Active in Journal</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <form onSubmit={handleCreate} className="w-full max-w-lg bg-[#0D131D] border border-[#243346] rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white">Create New Strategy Playbook Item</h3>
            <div>
              <label className="text-xs text-[#8492A6] block mb-1">Strategy Name</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. London Sweep of Asian High"
                required
                className="w-full bg-[#080B12] border border-[#222E40] rounded-xl px-3 py-2 text-xs text-white outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-[#8492A6] block mb-1">Setup Description & Market Logic</label>
              <textarea
                value={desc}
                onChange={e => setDesc(e.target.value)}
                rows={3}
                placeholder="What edge does this exploit?"
                className="w-full bg-[#080B12] border border-[#222E40] rounded-xl p-3 text-xs text-white outline-none resize-none"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 rounded-xl text-xs text-[#8492A6]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-[#3987FF] text-white text-xs font-bold"
              >
                Save Setup
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
