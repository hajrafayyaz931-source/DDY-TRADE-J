import React, { useState, useEffect, useMemo } from 'react';
import { 
  Trade, 
  TradingAccount, 
  RuleItem, 
  DailyPlaybookPlan, 
  StrategyItem, 
  GoalItem, 
  WeeklyReviewRecord,
  ChallengeDay
} from './types/trade';
import { 
  INITIAL_ACCOUNTS, 
  INITIAL_TRADES, 
  INITIAL_RULES, 
  INITIAL_DAILY_PLAYBOOK, 
  INITIAL_STRATEGIES, 
  INITIAL_GOALS, 
  INITIAL_WEEKLY_REVIEW 
} from './data/initialData';
import { INITIAL_CHALLENGE_DAYS } from './data/challengeData';
import { calculateStats } from './utils/calculations';

// Layout components
import { Navbar } from './components/layout/Navbar';
import { Sidebar, NavTab } from './components/layout/Sidebar';
import { CommandPalette } from './components/layout/CommandPalette';
import { MobileNav } from './components/layout/MobileNav';

// View components
import { DashboardView } from './components/views/DashboardView';
import { ChallengeTargetView } from './components/views/ChallengeTargetView';
import { GeminiChatbotView } from './components/views/GeminiChatbotView';
import { TradeJournalView } from './components/views/TradeJournalView';
import { AnalyticsView } from './components/views/AnalyticsView';
import { DailyJournalView } from './components/views/DailyJournalView';
import { RiskCalculatorView } from './components/views/RiskCalculatorView';
import { AICoachView } from './components/views/AICoachView';
import { RulesEngineView } from './components/views/RulesEngineView';
import { PsychologyView } from './components/views/PsychologyView';
import { WeeklyReviewView } from './components/views/WeeklyReviewView';
import { StrategyLabView } from './components/views/StrategyLabView';
import { LessonsLibraryView } from './components/views/LessonsLibraryView';
import { GoalsView } from './components/views/GoalsView';
import { PortfolioView } from './components/views/PortfolioView';
import { SettingsView } from './components/views/SettingsView';

// Modals
import { LogTradeModal } from './components/modals/LogTradeModal';
import { TradeDetailModal } from './components/modals/TradeDetailModal';
import { AutoImportModal } from './components/modals/AutoImportModal';
import { UrduGuideModal } from './components/modals/UrduGuideModal';
import { VisualsModal } from './components/modals/VisualsModal';
import { EditAccountModal } from './components/modals/EditAccountModal';
import { VisualSettings, THEME_DEFINITIONS } from './types/visuals';
import { playClickSound, playWinSound, playLossSound, speakTradeResult } from './utils/soundEffects';
import { Plus } from 'lucide-react';

export default function App() {
  // Persistence state
  const [trades, setTrades] = useState<Trade[]>(() => {
    try {
      const saved = localStorage.getItem('tradepath_trades_v4');
      if (saved) {
        const parsed: Trade[] = JSON.parse(saved);
        const quotexOnly = parsed.filter(t => 
          !t.symbol.includes('BTC') && 
          !t.symbol.includes('ES') && 
          !t.symbol.includes('NQ') &&
          t.accountId !== 'acc-binance-crypto' &&
          t.accountId !== 'acc-apex-50k'
        );
        if (quotexOnly.length > 0) return quotexOnly;
      }
    } catch (e) {}
    return INITIAL_TRADES;
  });

  const [accounts, setAccounts] = useState<TradingAccount[]>(() => {
    try {
      const saved = localStorage.getItem('tradepath_accounts_v4');
      if (saved) {
        const parsed: TradingAccount[] = JSON.parse(saved);
        const quotexOnly = parsed.filter(a => 
          a.broker.toLowerCase().includes('quotex') || 
          a.id.includes('quotex') || 
          a.name.toLowerCase().includes('quotex')
        );
        if (quotexOnly.length > 0) {
          // If acc-all name had Multi-Broker, rename to Quotex
          return quotexOnly.map(a => a.id === 'acc-all' ? { ...a, name: 'All Quotex Portfolios (Consolidated)', broker: 'Quotex Financial Terminal' } : a);
        }
      }
    } catch (e) {}
    return INITIAL_ACCOUNTS;
  });

  const [rules, setRules] = useState<RuleItem[]>(() => {
    try {
      const saved = localStorage.getItem('tradepath_rules_v4');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_RULES;
  });

  const [playbook, setPlaybook] = useState<DailyPlaybookPlan>(() => {
    try {
      const saved = localStorage.getItem('tradepath_playbook_v4');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_DAILY_PLAYBOOK;
  });

  const [strategies, setStrategies] = useState<StrategyItem[]>(() => {
    try {
      const saved = localStorage.getItem('tradepath_strategies_v4');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_STRATEGIES;
  });

  const [goals, setGoals] = useState<GoalItem[]>(() => {
    try {
      const saved = localStorage.getItem('tradepath_goals_v4');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_GOALS;
  });

  const [weeklyReview, setWeeklyReview] = useState<WeeklyReviewRecord>(() => {
    try {
      const saved = localStorage.getItem('tradepath_weekly_v4');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_WEEKLY_REVIEW;
  });

  const [challengeDays, setChallengeDays] = useState<ChallengeDay[]>(() => {
    try {
      const saved = localStorage.getItem('tradepath_challenge_days_v4');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_CHALLENGE_DAYS;
  });

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('tradepath_challenge_days_v4', JSON.stringify(challengeDays));
    } catch (e) {}
  }, [challengeDays]);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('tradepath_trades_v4', JSON.stringify(trades));
    } catch (e) {}
  }, [trades]);

  useEffect(() => {
    try {
      localStorage.setItem('tradepath_accounts_v4', JSON.stringify(accounts));
    } catch (e) {}
  }, [accounts]);

  useEffect(() => {
    try {
      localStorage.setItem('tradepath_rules_v4', JSON.stringify(rules));
    } catch (e) {}
  }, [rules]);

  // Navigation & View state
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [selectedAccountId, setSelectedAccountId] = useState('acc-all');
  const [selectedDateFilter, setSelectedDateFilter] = useState<string | null>(null);

  // Visual & Theme Settings
  const [visualSettings, setVisualSettings] = useState<VisualSettings>(() => {
    try {
      const saved = localStorage.getItem('tradepath_visual_settings_v1');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      theme: 'quotex-cyber',
      candleStyle: 'neon',
      pnlColorway: 'neon-vivid',
      density: 'comfortable',
      ambientGlow: true,
      soundEffects: true,
      voiceAlerts: true,
      gridIntensity: 'subtle',
    };
  });
  const [isVisualsOpen, setIsVisualsOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('tradepath_visual_settings_v1', JSON.stringify(visualSettings));
      document.documentElement.setAttribute('data-theme', visualSettings.theme);
      document.body.setAttribute('data-theme', visualSettings.theme);
      
      const themeDef = THEME_DEFINITIONS[visualSettings.theme] || THEME_DEFINITIONS['quotex-cyber'];
      if (themeDef) {
        const root = document.documentElement;
        root.style.setProperty('--bg-primary', themeDef.bgPrimary);
        root.style.setProperty('--surface-primary', themeDef.surfacePrimary);
        root.style.setProperty('--surface-secondary', themeDef.surfaceSecondary);
        root.style.setProperty('--surface-tertiary', themeDef.surfaceTertiary);
        root.style.setProperty('--accent-primary', themeDef.accentPrimary);
        root.style.setProperty('--accent-secondary', themeDef.accentSecondary);
        root.style.setProperty('--accent-glow', themeDef.accentSecondary);
        root.style.setProperty('--pnl-positive', themeDef.pnlPositive);
        root.style.setProperty('--pnl-negative', themeDef.pnlNegative);
        root.style.setProperty('--border-subtle', themeDef.borderColor);
        root.style.setProperty('--border-hover', themeDef.accentPrimary);
        root.style.setProperty('--glow-color', themeDef.glowColor);
        document.body.style.backgroundColor = themeDef.bgPrimary;
      }

      if (visualSettings.density === 'compact') {
        document.body.classList.add('density-compact');
      } else {
        document.body.classList.remove('density-compact');
      }
    } catch (e) {}
  }, [visualSettings]);

  // Modal dialog states
  const [isLogTradeOpen, setIsLogTradeOpen] = useState(false);
  const [isAutoImportOpen, setIsAutoImportOpen] = useState(false);
  const [isUrduGuideOpen, setIsUrduGuideOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isEditAccountOpen, setIsEditAccountOpen] = useState(false);
  const [inspectTrade, setInspectTrade] = useState<Trade | null>(null);

  const handleUpdateAccount = (updatedAccount: TradingAccount) => {
    const accTrades = trades.filter((t) => t.accountId === updatedAccount.id);
    const pnlSum = accTrades.reduce((tSum, t) => tSum + t.pnl, 0);
    const netStarting = Math.max(0, updatedAccount.currentBalance - pnlSum);

    const cleanAcc: TradingAccount = {
      ...updatedAccount,
      startingBalance: netStarting,
    };

    setAccounts((prev) => prev.map((a) => (a.id === cleanAcc.id ? cleanAcc : a)));
  };

  // Dynamically computed accounts with live trade PnL recalculation
  const computedAccounts = useMemo(() => {
    return accounts.map((acc) => {
      if (acc.id === 'acc-all') {
        const individual = accounts.filter((a) => a.id !== 'acc-all');
        const totalStarting = individual.reduce((s, a) => s + a.startingBalance, 0);
        const totalCurrent = individual.reduce((s, a) => {
          const accTrades = trades.filter((t) => t.accountId === a.id);
          const pnlSum = accTrades.reduce((tSum, t) => tSum + t.pnl, 0);
          return s + a.startingBalance + pnlSum;
        }, 0);

        return {
          ...acc,
          startingBalance: totalStarting,
          currentBalance: totalCurrent,
        };
      }

      const accTrades = trades.filter((t) => t.accountId === acc.id);
      const pnlSum = accTrades.reduce((tSum, t) => tSum + t.pnl, 0);
      return {
        ...acc,
        currentBalance: acc.startingBalance + pnlSum,
      };
    });
  }, [accounts, trades]);

  // Filtered trades based on account
  const accountTrades = selectedAccountId === 'acc-all'
    ? trades
    : trades.filter((t) => t.accountId === selectedAccountId);

  // Active account stats
  const activeAccount = computedAccounts.find((a: TradingAccount) => a.id === selectedAccountId) || computedAccounts[0];
  const calculatedStats = calculateStats(accountTrades, activeAccount.startingBalance);

  // Add trade handler
  const handleSaveTrade = (newTrade: Trade) => {
    setTrades((prev) => [newTrade, ...prev]);
    if (newTrade.pnl >= 0) {
      playWinSound(visualSettings.soundEffects);
    } else {
      playLossSound(visualSettings.soundEffects);
    }

    if (visualSettings.voiceAlerts) {
      speakTradeResult(
        newTrade.result === 'ITM' ? 'ITM' : newTrade.result === 'OTM' ? 'OTM' : 'ATM',
        newTrade.pnl,
        newTrade.symbol,
        true
      );
    }
  };

  // Import batch trades handler
  const handleImportTrades = (newTrades: Trade[]) => {
    setTrades((prev) => [...newTrades, ...prev]);
    playWinSound(visualSettings.soundEffects);
  };

  // Delete trade handler
  const handleDeleteTrade = (tradeId: string) => {
    setTrades((prev) => prev.filter((t) => t.id !== tradeId));
    if (inspectTrade?.id === tradeId) setInspectTrade(null);
  };

  // Sound-enhanced tab select
  const handleSelectTab = (tab: NavTab) => {
    playClickSound(visualSettings.soundEffects);
    setActiveTab(tab);
  };

  // Rule toggler
  const handleToggleRule = (id: number) => {
    setRules((prev) =>
      prev.map((r) => (r.id === id ? { ...r, active: !r.active } : r))
    );
  };

  // Add rule
  const handleAddRule = (item: Omit<RuleItem, 'id' | 'violationCount'>) => {
    const nextId = Math.max(...rules.map((r) => r.id), 0) + 1;
    setRules((prev) => [...prev, { ...item, id: nextId, violationCount: 0 }]);
  };

  // Delete rule
  const handleDeleteRule = (id: number) => {
    setRules((prev) => prev.filter((r) => r.id !== id));
  };

  const handleUpdateChallengeDay = (dayNum: number, updates: Partial<ChallengeDay>) => {
    setChallengeDays((prev) =>
      prev.map((d) => (d.day === dayNum ? { ...d, ...updates } : d))
    );
    if (updates.status === 'achieved') {
      playWinSound(visualSettings.soundEffects);
    }
  };

  const handleImportBackup = (backupData: any) => {
    if (Array.isArray(backupData)) {
      setTrades(backupData);
    } else if (backupData && typeof backupData === 'object') {
      if (Array.isArray(backupData.trades)) setTrades(backupData.trades);
      if (Array.isArray(backupData.accounts)) setAccounts(backupData.accounts);
      if (Array.isArray(backupData.rules)) setRules(backupData.rules);
      if (backupData.playbook) setPlaybook(backupData.playbook);
      if (Array.isArray(backupData.strategies)) setStrategies(backupData.strategies);
      if (Array.isArray(backupData.goals)) setGoals(backupData.goals);
      if (backupData.weeklyReview) setWeeklyReview(backupData.weeklyReview);
      if (Array.isArray(backupData.challengeDays)) setChallengeDays(backupData.challengeDays);
    }
  };

  // Factory reset
  const handleResetData = () => {
    setTrades(INITIAL_TRADES);
    setAccounts(INITIAL_ACCOUNTS);
    setRules(INITIAL_RULES);
    setPlaybook(INITIAL_DAILY_PLAYBOOK);
    setStrategies(INITIAL_STRATEGIES);
    setGoals(INITIAL_GOALS);
    setWeeklyReview(INITIAL_WEEKLY_REVIEW);
    setChallengeDays(INITIAL_CHALLENGE_DAYS);
    try {
      localStorage.clear();
    } catch (e) {}
  };

  const activeThemeDef = THEME_DEFINITIONS[visualSettings.theme] || THEME_DEFINITIONS['quotex-cyber'];

  return (
    <div 
      data-theme={visualSettings.theme} 
      style={{
        '--bg-primary': activeThemeDef.bgPrimary,
        '--surface-primary': activeThemeDef.surfacePrimary,
        '--surface-secondary': activeThemeDef.surfaceSecondary,
        '--surface-tertiary': activeThemeDef.surfaceTertiary,
        '--accent-primary': activeThemeDef.accentPrimary,
        '--accent-secondary': activeThemeDef.accentSecondary,
        '--accent-glow': activeThemeDef.accentSecondary,
        '--pnl-positive': activeThemeDef.pnlPositive,
        '--pnl-negative': activeThemeDef.pnlNegative,
        '--border-subtle': activeThemeDef.borderColor,
        '--border-hover': activeThemeDef.accentPrimary,
        '--glow-color': activeThemeDef.glowColor,
      } as React.CSSProperties}
      className="min-h-screen bg-[var(--bg-primary)] text-[#F3F6FC] flex flex-col antialiased relative selection:bg-[var(--accent-primary)] selection:text-white transition-colors duration-300"
    >
      {/* Ambient Glow Backdrop Layer */}
      {visualSettings.ambientGlow && (
        <div className="fixed inset-0 ambient-glow-layer z-0 pointer-events-none" />
      )}

      {/* Top Navbar */}
      <Navbar
        accounts={computedAccounts}
        selectedAccountId={selectedAccountId}
        onSelectAccount={setSelectedAccountId}
        onOpenLogTrade={() => setIsLogTradeOpen(true)}
        onOpenAutoImport={() => setIsAutoImportOpen(true)}
        onOpenUrduGuide={() => setIsUrduGuideOpen(true)}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onOpenChallenge={() => handleSelectTab('challenge')}
        onOpenGemini={() => handleSelectTab('gemini-chat')}
        onOpenVisuals={() => setIsVisualsOpen(true)}
        onOpenEditAccount={() => setIsEditAccountOpen(true)}
        activeTheme={visualSettings.theme}
        onSelectTheme={(tId) => setVisualSettings(prev => ({ ...prev, theme: tId }))}
        activeThemeName={THEME_DEFINITIONS[visualSettings.theme]?.name || 'Institutional Dark Purple'}
        activeStreak={calculatedStats.currentStreak}
        isDarkMode={visualSettings.theme !== 'institutional-light'}
        onToggleDarkMode={() => {
          setVisualSettings(prev => ({
            ...prev,
            theme: prev.theme === 'institutional-light' ? 'quotex-cyber' : 'institutional-light'
          }));
        }}
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={handleSelectTab}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          tradeCount={accountTrades.length}
          adherenceRate={calculatedStats.rulesAdherencePercent}
          onOpenVisuals={() => setIsVisualsOpen(true)}
        />

        {/* Dynamic Main View Area */}
        <main className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-8 max-w-7xl mx-auto w-full">
          {activeTab === 'dashboard' && (
            <DashboardView
              trades={accountTrades}
              stats={calculatedStats}
              account={activeAccount}
              onOpenLogTrade={() => setIsLogTradeOpen(true)}
              onOpenAutoImport={() => setIsAutoImportOpen(true)}
              onSelectTrade={(t) => setInspectTrade(t)}
              onSelectDate={(dateStr) => {
                setSelectedDateFilter(dateStr);
                if (dateStr) setActiveTab('journal');
              }}
              selectedDate={selectedDateFilter}
              onOpenChallenge={() => setActiveTab('challenge')}
            />
          )}

          {activeTab === 'challenge' && (
            <ChallengeTargetView
              challengeDays={challengeDays}
              onUpdateDay={handleUpdateChallengeDay}
              todayTrades={accountTrades}
            />
          )}

          {activeTab === 'gemini-chat' && (
            <GeminiChatbotView
              trades={accountTrades}
              challengeDays={challengeDays}
            />
          )}

          {activeTab === 'journal' && (
            <TradeJournalView
              trades={accountTrades}
              onSelectTrade={(t) => setInspectTrade(t)}
              onOpenLogTrade={() => setIsLogTradeOpen(true)}
              onOpenAutoImport={() => setIsAutoImportOpen(true)}
              onDeleteTrade={handleDeleteTrade}
              selectedDateFilter={selectedDateFilter}
              onClearDateFilter={() => setSelectedDateFilter(null)}
            />
          )}

          {activeTab === 'playbook' && (
            <DailyJournalView
              plan={playbook}
              onSavePlan={setPlaybook}
              trades={accountTrades}
            />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsView
              trades={accountTrades}
              stats={calculatedStats}
              account={activeAccount}
              onOpenLogTrade={() => setIsLogTradeOpen(true)}
            />
          )}

          {activeTab === 'calculator' && (
            <RiskCalculatorView />
          )}

          {activeTab === 'ai-coach' && (
            <AICoachView
              trades={accountTrades}
            />
          )}

          {activeTab === 'rules' && (
            <RulesEngineView
              rules={rules}
              trades={accountTrades}
              onToggleRule={handleToggleRule}
              onAddRule={handleAddRule}
              onDeleteRule={handleDeleteRule}
            />
          )}

          {activeTab === 'psychology' && (
            <PsychologyView
              trades={accountTrades}
            />
          )}

          {activeTab === 'calendar' && (
            <div className="space-y-4">
              <h1 className="text-xl lg:text-2xl font-extrabold text-white tracking-tight">
                Trading Calendar & Monthly Performance
              </h1>
              <DashboardView
                trades={accountTrades}
                stats={calculatedStats}
                account={activeAccount}
                onOpenLogTrade={() => setIsLogTradeOpen(true)}
                onOpenAutoImport={() => setIsAutoImportOpen(true)}
                onSelectTrade={(t) => setInspectTrade(t)}
                onSelectDate={(dateStr) => {
                  setSelectedDateFilter(dateStr);
                  if (dateStr) setActiveTab('journal');
                }}
                selectedDate={selectedDateFilter}
              />
            </div>
          )}

          {activeTab === 'review' && (
            <WeeklyReviewView
              review={weeklyReview}
              trades={accountTrades}
              onSaveReview={setWeeklyReview}
            />
          )}

          {activeTab === 'strategy' && (
            <StrategyLabView
              strategies={strategies}
              trades={accountTrades}
              onAddStrategy={(newS) => setStrategies((prev) => [...prev, newS])}
            />
          )}

          {activeTab === 'goals' && (
            <GoalsView
              goals={goals}
              stats={calculatedStats}
            />
          )}

          {activeTab === 'portfolio' && (
            <PortfolioView
              accounts={computedAccounts}
              trades={trades}
              selectedAccountId={selectedAccountId}
              onSelectAccount={setSelectedAccountId}
              onOpenEditAccount={() => setIsEditAccountOpen(true)}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              trades={trades}
              accounts={computedAccounts}
              rules={rules}
              playbook={playbook}
              strategies={strategies}
              goals={goals}
              weeklyReview={weeklyReview}
              challengeDays={challengeDays}
              onImportBackup={handleImportBackup}
              onResetData={handleResetData}
              onOpenVisuals={() => setIsVisualsOpen(true)}
              onOpenEditAccount={() => setIsEditAccountOpen(true)}
            />
          )}
        </main>
      </div>

      {/* Floating Quick Action "+" Button with Theme Reactive Glow Ring */}
      <button
        onClick={() => {
          playClickSound(visualSettings.soundEffects);
          setIsLogTradeOpen(true);
        }}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full floating-plus-btn flex items-center justify-center text-white ring-4 ring-[var(--accent-primary)]/40 shadow-[0_0_28px_var(--glow-color)] hover:ring-[var(--accent-secondary)]/70 hover:shadow-[0_0_40px_var(--glow-color)] group cursor-pointer"
        title="Quick Log Trade (+)"
      >
        <Plus size={24} className="group-hover:rotate-90 transition-transform duration-300 drop-shadow-[0_0_6px_rgba(255,255,255,0.7)]" />
      </button>

      {/* Mobile Bottom Navigation */}
      <MobileNav
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        onOpenLogTrade={() => setIsLogTradeOpen(true)}
      />

      {/* Global Modals */}
      <LogTradeModal
        isOpen={isLogTradeOpen}
        onClose={() => setIsLogTradeOpen(false)}
        onSaveTrade={handleSaveTrade}
        accounts={computedAccounts.filter((a: TradingAccount) => a.id !== 'acc-all')}
        rules={rules}
        defaultAccountId={selectedAccountId === 'acc-all' ? 'acc-quotex-live' : selectedAccountId}
      />

      <AutoImportModal
        isOpen={isAutoImportOpen}
        onClose={() => setIsAutoImportOpen(false)}
        onImportTrades={handleImportTrades}
      />

      <TradeDetailModal
        trade={inspectTrade}
        onClose={() => setInspectTrade(null)}
        onDeleteTrade={handleDeleteTrade}
        candleStyle={visualSettings.candleStyle}
      />

      <UrduGuideModal
        isOpen={isUrduGuideOpen}
        onClose={() => setIsUrduGuideOpen(false)}
      />

      <VisualsModal
        isOpen={isVisualsOpen}
        onClose={() => setIsVisualsOpen(false)}
        settings={visualSettings}
        onUpdateSettings={(newSettings) =>
          setVisualSettings((prev) => ({ ...prev, ...newSettings }))
        }
        onResetSettings={() =>
          setVisualSettings({
            theme: 'quotex-cyber',
            candleStyle: 'neon',
            pnlColorway: 'neon-vivid',
            density: 'comfortable',
            ambientGlow: true,
            soundEffects: true,
            voiceAlerts: true,
            gridIntensity: 'subtle',
          })
        }
      />

      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onSelectTab={handleSelectTab}
        onOpenLogTrade={() => {
          setIsCommandPaletteOpen(false);
          setIsLogTradeOpen(true);
        }}
        onOpenAutoImport={() => {
          setIsCommandPaletteOpen(false);
          setIsAutoImportOpen(true);
        }}
        trades={accountTrades}
        onSelectTrade={(t) => {
          setInspectTrade(t);
        }}
        onOpenVisuals={() => setIsVisualsOpen(true)}
      />

      <EditAccountModal
        isOpen={isEditAccountOpen}
        onClose={() => setIsEditAccountOpen(false)}
        accounts={computedAccounts}
        selectedAccountId={selectedAccountId}
        onUpdateAccount={handleUpdateAccount}
      />
    </div>
  );
}
