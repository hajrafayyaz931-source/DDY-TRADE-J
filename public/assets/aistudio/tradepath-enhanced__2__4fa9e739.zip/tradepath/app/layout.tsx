import type { Metadata, Viewport } from 'next';
import './globals.css';
export const metadata: Metadata = { title:'TradePath — Trading Journal', description:'Plan with intention. Trade with discipline. Review with clarity.', applicationName:'TradePath', manifest:'/manifest.json' };
export const viewport: Viewport = { themeColor:'#080b10', width:'device-width', initialScale:1 };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }
