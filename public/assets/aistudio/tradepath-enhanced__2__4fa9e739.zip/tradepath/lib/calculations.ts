export type TradeSide = 'Long' | 'Short';
export function calculateTrade(input: { side: TradeSide; entry: number; exit: number; stopLoss: number; size: number; fees?: number }) {
  const { side, entry, exit, stopLoss, size } = input;
  const fees = input.fees ?? 0;
  if (![entry, exit, stopLoss, size, fees].every(Number.isFinite) || entry <= 0 || size < 0) return { pnl: 0, risk: 0, rMultiple: 0 };
  const direction = side === 'Long' ? 1 : -1;
  const pnl = (exit - entry) * direction * size - fees;
  const risk = Math.abs(entry - stopLoss) * size;
  return { pnl, risk, rMultiple: risk > 0 ? pnl / risk : 0 };
}
export function formatMoney(value: number, currency = 'USD') {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 2 }).format(value);
}
export function calculateStats(trades: Array<{ pnl: number; r_multiple: number }>) {
  const wins = trades.filter(t => t.pnl > 0), losses = trades.filter(t => t.pnl < 0);
  const grossWin = wins.reduce((s,t) => s+t.pnl,0), grossLoss = Math.abs(losses.reduce((s,t)=>s+t.pnl,0));
  return { totalPnl: trades.reduce((s,t)=>s+t.pnl,0), winRate: trades.length ? wins.length/trades.length*100 : 0, profitFactor: grossLoss ? grossWin/grossLoss : grossWin ? Infinity : 0, expectancy: trades.length ? trades.reduce((s,t)=>s+t.pnl,0)/trades.length : 0, averageR: trades.length ? trades.reduce((s,t)=>s+t.r_multiple,0)/trades.length : 0 };
}
