-- TradePath schema for Supabase/Postgres. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;
create type public.trade_direction as enum ('Long','Short');
create type public.market_bias as enum ('Bullish','Bearish','Neutral');
create type public.rule_category as enum ('Risk Management','Entry Criteria','Psychology','Exit Rules','Other');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  preferred_currency text not null default 'USD',
  timezone text not null default 'UTC',
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.trading_accounts (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  name text not null, broker text, account_type text not null default 'Personal', currency text not null default 'USD',
  starting_balance numeric(20,8) not null default 0, is_default boolean not null default false, archived_at timestamptz,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create unique index one_default_account_per_user on public.trading_accounts(user_id) where is_default and archived_at is null;
create table public.strategies (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  name text not null, description text, archived_at timestamptz, created_at timestamptz not null default now(),
  unique(user_id,name)
);
create table public.rules (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  title text not null, description text, category public.rule_category not null default 'Other', is_active boolean not null default true,
  sort_order integer not null default 0, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.daily_plans (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  plan_date date not null, account_id uuid references public.trading_accounts(id) on delete set null,
  market_bias public.market_bias not null default 'Neutral', levels jsonb not null default '{}'::jsonb,
  watchlist jsonb not null default '[]'::jsonb, planned_setups jsonb not null default '[]'::jsonb,
  max_risk_pct numeric(8,4) not null default 1 check(max_risk_pct >= 0), max_daily_loss numeric(20,8), max_trades integer check(max_trades is null or max_trades >= 0),
  intention text, confidence smallint check(confidence between 1 and 10), created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique(user_id,plan_date,account_id)
);
create table public.trades (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  account_id uuid not null references public.trading_accounts(id) on delete restrict, strategy_id uuid references public.strategies(id) on delete set null,
  symbol text not null, direction public.trade_direction not null, timeframe text, session text,
  entry_price numeric(28,10) not null check(entry_price > 0), exit_price numeric(28,10), stop_loss numeric(28,10), take_profit numeric(28,10),
  position_size numeric(28,10) not null check(position_size > 0), contract_multiplier numeric(28,10) not null default 1 check(contract_multiplier > 0),
  risk_amount numeric(20,8), fees numeric(20,8) not null default 0, funding numeric(20,8) not null default 0,
  pnl numeric(20,8), r_multiple numeric(20,8), opened_at timestamptz not null default now(), closed_at timestamptz,
  status text not null default 'Closed' check(status in ('Open','Closed','Cancelled')),
  notes text, lessons text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index trades_user_date_idx on public.trades(user_id,opened_at desc);
create index trades_user_symbol_idx on public.trades(user_id,symbol);
create table public.trade_rule_checks (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  trade_id uuid not null references public.trades(id) on delete cascade, rule_id uuid references public.rules(id) on delete set null,
  rule_title_snapshot text not null, followed boolean not null, note text, created_at timestamptz not null default now(), unique(trade_id,rule_id)
);
create table public.trade_emotions (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  trade_id uuid not null references public.trades(id) on delete cascade,
  emotion text not null check(emotion in ('Fear','FOMO','Confidence','Revenge','Calm','Greed','Boredom','Anxious','Frustrated','Focused','Other')),
  phase text not null default 'During' check(phase in ('Before','During','After')), intensity smallint check(intensity between 1 and 10), created_at timestamptz not null default now()
);
create table public.trade_screenshots (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  trade_id uuid not null references public.trades(id) on delete cascade, storage_path text not null,
  phase text not null check(phase in ('Before','After')), caption text, created_at timestamptz not null default now()
);
create table public.psychology_logs (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  log_date date not null, emotional_state text not null, discipline_score smallint check(discipline_score between 1 and 10), stress_score smallint check(stress_score between 1 and 10), notes text,
  created_at timestamptz not null default now(), unique(user_id,log_date)
);
create table public.weekly_reviews (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  week_start date not null, account_id uuid references public.trading_accounts(id) on delete set null,
  went_well text, needs_improvement text, key_lesson text, focus_goals jsonb not null default '[]'::jsonb, growth_score smallint check(growth_score between 0 and 100),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(user_id,week_start,account_id)
);
create table public.goals (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  title text not null, goal_type text not null check(goal_type in ('Profit','Process','Streak','Other')), target_value numeric(20,8), current_value numeric(20,8) not null default 0,
  starts_on date, ends_on date, unit text, is_active boolean not null default true, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

-- Keep profile rows in sync with Supabase Auth.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = '' as $$
begin insert into public.profiles(id,display_name) values(new.id, coalesce(new.raw_user_meta_data->>'full_name',new.raw_user_meta_data->>'name')); return new; end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Owner-only access to every user-owned table. Do not use service-role keys in the browser.
do $$ declare t text; begin
  foreach t in array array['profiles','trading_accounts','strategies','rules','daily_plans','trades','trade_rule_checks','trade_emotions','trade_screenshots','psychology_logs','weekly_reviews','goals'] loop
    execute format('alter table public.%I enable row level security',t);
    execute format('create policy "owner can read" on public.%I for select to authenticated using (auth.uid() = user_id or ( %L = ''profiles'' and auth.uid() = id))',t,t);
    if t = 'profiles' then
      execute 'create policy "owner can insert profile" on public.profiles for insert to authenticated with check (auth.uid() = id)';
      execute 'create policy "owner can update profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id)';
    else
      execute format('create policy "owner can insert" on public.%I for insert to authenticated with check (auth.uid() = user_id)',t);
      execute format('create policy "owner can update" on public.%I for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id)',t);
      execute format('create policy "owner can delete" on public.%I for delete to authenticated using (auth.uid() = user_id)',t);
    end if;
  end loop;
end $$;

-- Private screenshot bucket. Storage policies restrict each object to its owner folder: <auth.uid()>/<trade-id>/<filename>.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('trade-screenshots','trade-screenshots',false,10485760,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
create policy "owner can read own screenshots" on storage.objects for select to authenticated using (bucket_id='trade-screenshots' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "owner can upload own screenshots" on storage.objects for insert to authenticated with check (bucket_id='trade-screenshots' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "owner can delete own screenshots" on storage.objects for delete to authenticated using (bucket_id='trade-screenshots' and (storage.foldername(name))[1]=auth.uid()::text);
