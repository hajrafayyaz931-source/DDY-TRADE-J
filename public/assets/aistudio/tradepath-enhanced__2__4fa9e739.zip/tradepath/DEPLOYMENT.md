# Deployment notes

## Vercel
- Import the repository into Vercel.
- Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` environment variables.
- Set the production domain in Supabase Auth redirect URL configuration.
- Deploy and run the SQL schema before enabling real users.

## Before handling real user data
- Wire authentication and protect private routes; current page is a UI preview.
- Verify every database operation is scoped by `auth.uid()` and account ownership.
- Add automated tests for PnL/R calculations, especially short trades, zero-risk trades, fees, contract multipliers, and partial exits.
- Check database policies in a separate test user account and attempt cross-user reads/writes.
- Configure backup/restore, monitoring, abuse controls, legal/privacy notices, and retention policy.
