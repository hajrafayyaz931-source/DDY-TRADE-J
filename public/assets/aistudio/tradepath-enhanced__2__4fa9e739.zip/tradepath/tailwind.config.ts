import type { Config } from 'tailwindcss';
const config: Config = { content: ['./app/**/*.{js,ts,jsx,tsx,mdx}','./components/**/*.{js,ts,jsx,tsx,mdx}'], theme: { extend: { colors: { base:'#080b10', panel:'#10151d', line:'#202936', muted:'#8b98a9', green:'#38d996', red:'#ff647c', blue:'#6da8ff' }, boxShadow:{ glow:'0 12px 40px rgba(0,0,0,.22)' } } }, plugins: [] };
export default config;
