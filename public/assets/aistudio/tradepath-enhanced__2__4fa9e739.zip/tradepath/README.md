# TradePath

A dark-first, responsive trading journal starter built with Next.js App Router, TypeScript, Tailwind CSS, Recharts, and Supabase. The UI includes a dashboard, daily plan, journal, trade-entry modal with PnL/risk/R calculations, analytics, rules, weekly review, psychology tracker, goals, and settings.

## Important implementation status

This source package includes a functional interactive front-end using sample data held in component state, a Supabase browser-client helper, and a database schema with owner-scoped Row Level Security. **The sample UI is not yet a fully wired production service**: authentication screens/provider callbacks, CRUD queries for each page, live computed analytics, screenshot upload wiring, offline queueing, and PDF generation need to be connected and tested before using real trading data. The UI labels those demo-only paths rather than pretending data is persisted. Do not treat sample metrics as actual trading performance.

## Run locally

1. Install Node.js 20+.
2. Copy `.env.example` to `.env.local` and add the project URL and anon key from Supabase.
3. In Supabase SQL Editor, run `supabase/schema.sql`.
4. In the project directory, run:
   ```bash
   npm install
   npm run dev
   ```
5. Open `http://localhost:3000`.

The front-end can be previewed without Supabase credentials; backend features require a configured Supabase project. Never expose the Supabase service-role key in client code.

## Supabase setup checklist

- Enable Email/password and Google provider in Authentication → Providers; configure OAuth redirect URLs for local and production domains.
- Configure email confirmation, password reset, allowed redirect URLs, SMTP, and session policies.
- Apply `supabase/schema.sql` and review policies against your organization's requirements before production.
- Keep screenshot storage private; use signed URLs and validate file size/type server-side.
- Add server-side authorization checks to all mutations and ensure account ownership is verified for related IDs.
- Set up database backups, error monitoring, rate limits, and privacy/retention policy.

## Trade calculation assumptions

The helper calculates `PnL = (exit - entry) × direction × size - fees` and `risk = abs(entry - stop) × size`; R-multiple is PnL divided by initial risk. This assumes the entered size represents units and price is quoted in a compatible currency. Futures contract multipliers, FX conversions, options Greeks, funding, slippage, partial fills, and broker-specific conventions must be supported for the instruments you trade before relying on results. The sample modal does not include fees or contract multipliers.

## Suggested production milestones

1. Implement Supabase Auth (email/password, Google OAuth, sign-out, password recovery) and protected routes.
2. Replace sample state with typed repository functions and database CRUD, including optimistic updates and loading/error states.
3. Add server-side calculation normalization for asset classes and fee models.
4. Wire private screenshot uploads and signed image URLs.
5. Implement date-range/session filters and analytics from persisted trades; add automated tests for calculations and RLS.
6. Generate PDF reports server-side, implement offline draft queue + conflict resolution, and add accessibility/device testing.

## Enhanced visual analytics and risk calculator

The dashboard now includes an interactive pre-trade position sizing panel. Inputs include account balance, risk percentage, entry, stop, target, and value per point/unit. It derives risk budget, approximate units/contracts, potential reward, and planned reward-to-risk ratio in real time. The equity curve and peak-to-trough drawdown are computed from the trades currently loaded in the browser session rather than using the prior hardcoded headline figures. R-multiple histogram buckets also count the currently loaded trade records.

**Calculation caveat:** this calculator is a planning estimate, not broker execution logic. Confirm point value, contract multipliers, lot increments, fees, slippage, funding, and instrument-specific PnL conventions before relying on its size estimate. Current sample trades remain in-memory demo data until repository CRUD and authentication are connected to Supabase.
